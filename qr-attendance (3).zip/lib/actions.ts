"use server"

import { revalidatePath } from "next/cache"

// Mock database
const employees: any[] = []
const attendanceRecords: any[] = []
let securityLogs: any[] = []

// Generate some initial data
if (attendanceRecords.length === 0) {
  const departments = ["engineering", "marketing", "finance", "hr", "operations"]

  // Create 25 employees
  for (let i = 1; i <= 25; i++) {
    const empId = `EMP${i.toString().padStart(3, "0")}`
    const deptIndex = Math.floor(Math.random() * departments.length)

    employees.push({
      id: empId,
      name: `Employee ${i}`,
      department: departments[deptIndex],
      faceData: `face_template_${i}`, // Simulated face template data
    })

    // Create check-in records for some employees
    if (Math.random() > 0.2) {
      // 80% of employees checked in
      const hour = 8 + Math.floor(Math.random() * 3) // 8-10 AM
      const minute = Math.floor(Math.random() * 60)
      const isLate = hour > 9 || (hour === 9 && minute > 30)

      const checkInTime = new Date()
      checkInTime.setHours(hour, minute, 0)

      attendanceRecords.push({
        id: `ci-${empId}`,
        employeeId: empId,
        employeeName: `Employee ${i}`,
        department: departments[deptIndex],
        type: "check-in",
        timestamp: checkInTime.toISOString(),
        isLate,
        verificationMethod: Math.random() > 0.3 ? "facial+geolocation" : "qr",
        location: {
          latitude: 37.7749 + (Math.random() - 0.5) * 0.01,
          longitude: -122.4194 + (Math.random() - 0.5) * 0.01,
        },
      })

      // Create check-out records for some employees who checked in
      if (Math.random() > 0.3) {
        // 70% of checked-in employees checked out
        const checkOutHour = 16 + Math.floor(Math.random() * 3) // 4-6 PM
        const checkOutMinute = Math.floor(Math.random() * 60)

        const checkOutTime = new Date()
        checkOutTime.setHours(checkOutHour, checkOutMinute, 0)

        attendanceRecords.push({
          id: `co-${empId}`,
          employeeId: empId,
          employeeName: `Employee ${i}`,
          department: departments[deptIndex],
          type: "check-out",
          timestamp: checkOutTime.toISOString(),
          verificationMethod: Math.random() > 0.3 ? "facial+geolocation" : "qr",
          location: {
            latitude: 37.7749 + (Math.random() - 0.5) * 0.01,
            longitude: -122.4194 + (Math.random() - 0.5) * 0.01,
          },
        })
      }
    }
  }

  // Generate some security logs
  securityLogs = [
    {
      id: "log-001",
      type: "face_verification_failed",
      employeeId: "EMP005",
      employeeName: "Employee 5",
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), // 2 hours ago
      details: "Face verification failed with 62% match (below threshold)",
    },
    {
      id: "log-002",
      type: "location_verification_failed",
      employeeId: "EMP015",
      employeeName: "Employee 15",
      timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), // 1 day ago
      details: "Location was 1.2 km away from approved office location",
    },
    {
      id: "log-003",
      type: "settings_changed",
      userId: "admin",
      userEmail: "admin@company.com",
      timestamp: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days ago
      details: "Changed face match threshold from 75% to 80%",
    },
  ]
}

export async function saveEmployee(employeeData: any) {
  // In a real app, this would save to a database
  const newEmployee = {
    ...employeeData,
    id:
      employeeData.id ||
      `EMP${Math.floor(Math.random() * 1000)
        .toString()
        .padStart(3, "0")}`,
    faceData: `face_template_${Math.random().toString(36).substring(2, 15)}`, // Simulated face template
  }

  employees.push(newEmployee)
  revalidatePath("/register")
  return newEmployee
}

export async function logAttendance(attendanceData: any) {
  // In a real app, this would save to a database
  const newRecord = {
    ...attendanceData,
    id: `${attendanceData.type.charAt(0)}-${attendanceData.employeeId}-${Date.now()}`,
    isLate: attendanceData.type === "check-in" && new Date().getHours() >= 9 && new Date().getMinutes() > 30,
  }

  attendanceRecords.push(newRecord)
  revalidatePath("/scan")
  revalidatePath("/dashboard")
  revalidatePath("/security")
  return newRecord
}

export async function getAttendanceRecords({
  date,
  dateRange,
  department,
  searchQuery,
  verificationMethod,
}: {
  date?: string
  dateRange?: { from: string; to: string }
  department?: string
  searchQuery?: string
  verificationMethod?: string
}) {
  // In a real app, this would query a database
  let filteredRecords = [...attendanceRecords]

  if (date) {
    const dateStr = date.split("T")[0]
    filteredRecords = filteredRecords.filter((record) => {
      const recordDate = new Date(record.timestamp).toISOString().split("T")[0]
      return recordDate === dateStr
    })
  }

  if (dateRange) {
    const fromDate = new Date(dateRange.from).getTime()
    const toDate = new Date(dateRange.to).getTime()

    filteredRecords = filteredRecords.filter((record) => {
      const recordDate = new Date(record.timestamp).getTime()
      return recordDate >= fromDate && recordDate <= toDate
    })
  }

  if (department) {
    filteredRecords = filteredRecords.filter((record) => record.department.toLowerCase() === department.toLowerCase())
  }

  if (searchQuery) {
    const query = searchQuery.toLowerCase()
    filteredRecords = filteredRecords.filter(
      (record) => record.employeeName.toLowerCase().includes(query) || record.employeeId.toLowerCase().includes(query),
    )
  }

  if (verificationMethod) {
    filteredRecords = filteredRecords.filter((record) => record.verificationMethod === verificationMethod)
  }

  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 500))

  return filteredRecords
}

export async function getSecurityLogs({
  type,
  dateRange,
}: {
  type?: string
  dateRange?: { from: string; to: string }
}) {
  // In a real app, this would query a database
  let filteredLogs = [...securityLogs]

  if (type) {
    filteredLogs = filteredLogs.filter((log) => log.type === type)
  }

  if (dateRange) {
    const fromDate = new Date(dateRange.from).getTime()
    const toDate = new Date(dateRange.to).getTime()

    filteredLogs = filteredLogs.filter((log) => {
      const logDate = new Date(log.timestamp).getTime()
      return logDate >= fromDate && logDate <= toDate
    })
  }

  // Simulate network delay
  await new Promise((resolve) => setTimeout(resolve, 500))

  return filteredLogs
}

export async function updateSecuritySettings(settings: any) {
  // In a real app, this would save to a database

  // Log the change
  securityLogs.push({
    id: `log-${Date.now()}`,
    type: "settings_changed",
    userId: "current_user",
    userEmail: "admin@company.com",
    timestamp: new Date().toISOString(),
    details: `Updated security settings: ${JSON.stringify(settings)}`,
  })

  revalidatePath("/security")
  return { success: true }
}

