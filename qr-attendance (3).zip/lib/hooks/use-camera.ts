"use client"

import { useState, useEffect, useRef } from "react"

interface UseCameraOptions {
  facingMode?: "user" | "environment"
  onStream?: (stream: MediaStream) => void
  onError?: (error: Error) => void
}

export function useCamera({ facingMode = "environment", onStream, onError }: UseCameraOptions = {}) {
  const [stream, setStream] = useState<MediaStream | null>(null)
  const [error, setError] = useState<Error | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const streamRef = useRef<MediaStream | null>(null)

  const startCamera = async () => {
    try {
      setIsLoading(true)
      setError(null)

      // Check if browser supports mediaDevices
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Camera access is not supported in your browser")
      }

      // Stop any existing stream
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop())
      }

      // Get available video devices
      const devices = await navigator.mediaDevices.enumerateDevices()
      const videoDevices = devices.filter((device) => device.kind === "videoinput")

      // Request camera access
      const newStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode,
          width: { ideal: 1280 },
          height: { ideal: 720 },
          frameRate: { ideal: 30 },
        },
      })

      streamRef.current = newStream
      setStream(newStream)
      onStream?.(newStream)
    } catch (err: any) {
      console.error("Camera error:", err)
      setError(err)
      onError?.(err)
    } finally {
      setIsLoading(false)
    }
  }

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
      setStream(null)
    }
  }

  const switchCamera = async () => {
    const currentFacingMode = facingMode === "user" ? "environment" : "user"
    stopCamera()
    await startCamera()
  }

  useEffect(() => {
    return () => {
      stopCamera()
    }
  }, [])

  return {
    stream,
    error,
    isLoading,
    startCamera,
    stopCamera,
    switchCamera,
  }
}

