"use client"

import { useState, useEffect, useRef } from "react"
import * as faceapi from "face-api.js"

interface UseFaceDetectionOptions {
  onDetection?: (detection: faceapi.FaceDetection) => void
  onMatch?: (match: boolean) => void
  onError?: (error: Error) => void
  matchThreshold?: number
}

export function useFaceDetection({
  onDetection,
  onMatch,
  onError,
  matchThreshold = 0.6,
}: UseFaceDetectionOptions = {}) {
  const [isInitialized, setIsInitialized] = useState(false)
  const [isDetecting, setIsDetecting] = useState(false)
  const [detection, setDetection] = useState<faceapi.FaceDetection | null>(null)
  const detectionIntervalRef = useRef<number | null>(null)

  // Initialize face-api models
  const initializeFaceDetection = async () => {
    try {
      await Promise.all([
        faceapi.nets.tinyFaceDetector.loadFromUri("/models"),
        faceapi.nets.faceLandmark68Net.loadFromUri("/models"),
        faceapi.nets.faceRecognitionNet.loadFromUri("/models"),
      ])
      setIsInitialized(true)
    } catch (error) {
      console.error("Error initializing face detection:", error)
      onError?.(error as Error)
    }
  }

  const startDetection = async (videoElement: HTMLVideoElement) => {
    if (!isInitialized) {
      await initializeFaceDetection()
    }

    setIsDetecting(true)
    setDetection(null)

    // Clear any existing interval
    if (detectionIntervalRef.current) {
      clearInterval(detectionIntervalRef.current)
    }

    // Start detection interval
    detectionIntervalRef.current = window.setInterval(async () => {
      if (!isDetecting || !videoElement.readyState === videoElement.HAVE_ENOUGH_DATA) return

      try {
        const detection = await faceapi.detectSingleFace(videoElement, new faceapi.TinyFaceDetectorOptions())

        if (detection) {
          setDetection(detection)
          onDetection?.(detection)

          // Simulate face matching (in a real app, you'd compare with stored face data)
          const match = detection.score > matchThreshold
          onMatch?.(match)

          if (match) {
            stopDetection()
          }
        }
      } catch (error) {
        console.error("Face detection error:", error)
        onError?.(error as Error)
      }
    }, 100)
  }

  const stopDetection = () => {
    setIsDetecting(false)
    if (detectionIntervalRef.current) {
      clearInterval(detectionIntervalRef.current)
      detectionIntervalRef.current = null
    }
  }

  useEffect(() => {
    return () => {
      if (detectionIntervalRef.current) {
        clearInterval(detectionIntervalRef.current)
      }
    }
  }, [])

  return {
    isInitialized,
    isDetecting,
    detection,
    startDetection,
    stopDetection,
  }
}

