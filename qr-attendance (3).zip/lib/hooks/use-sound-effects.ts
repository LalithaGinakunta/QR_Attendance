"use client"

import { useEffect, useRef } from "react"

type SoundType = "success" | "error" | "scan" | "notification"

export function useSoundEffects() {
  const audioRefs = useRef<Record<SoundType, HTMLAudioElement | null>>({
    success: null,
    error: null,
    scan: null,
    notification: null,
  })

  // Initialize audio elements
  useEffect(() => {
    // Only create audio elements on client side
    if (typeof window !== "undefined") {
      // Success sound
      audioRefs.current.success = new Audio("/sounds/success.mp3")
      audioRefs.current.success.preload = "auto"

      // Error sound
      audioRefs.current.error = new Audio("/sounds/error.mp3")
      audioRefs.current.error.preload = "auto"

      // Scan sound
      audioRefs.current.scan = new Audio("/sounds/scan.mp3")
      audioRefs.current.scan.preload = "auto"

      // Notification sound
      audioRefs.current.notification = new Audio("/sounds/notification.mp3")
      audioRefs.current.notification.preload = "auto"
    }

    // Cleanup on unmount
    return () => {
      Object.values(audioRefs.current).forEach((audio) => {
        if (audio) {
          audio.pause()
          audio.src = ""
        }
      })
    }
  }, [])

  // Play sound with optional volume control
  const playSound = (type: SoundType, volume = 0.5) => {
    const audio = audioRefs.current[type]
    if (audio) {
      // Reset audio to beginning if it's already playing
      audio.pause()
      audio.currentTime = 0

      // Set volume and play
      audio.volume = volume

      // Play with user interaction handling
      const playPromise = audio.play()

      if (playPromise !== undefined) {
        playPromise.catch((error) => {
          // Auto-play was prevented, we'll need user interaction
          console.warn("Audio playback was prevented:", error)
        })
      }
    }
  }

  // Provide haptic feedback if available (mobile devices)
  const vibrate = (pattern: number | number[] = 200) => {
    if (typeof navigator !== "undefined" && navigator.vibrate) {
      navigator.vibrate(pattern)
    }
  }

  return {
    playSound,
    vibrate,
    // Combined feedback function
    feedback: (type: SoundType, withVibration = true) => {
      playSound(type)
      if (withVibration) {
        vibrate(type === "success" ? [100, 50, 100] : 200)
      }
    },
  }
}

