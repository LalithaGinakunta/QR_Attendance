"use client"

import { useState, useEffect, useRef } from "react"
import jsQR from "jsqr"

interface UseQRScannerOptions {
  onResult?: (result: string) => void
  onError?: (error: Error) => void
}

export function useQRScanner({ onResult, onError }: UseQRScannerOptions = {}) {
  const [isScanning, setIsScanning] = useState(false)
  const [lastResult, setLastResult] = useState<string | null>(null)
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const scanIntervalRef = useRef<number | null>(null)

  const processVideoFrame = (video: HTMLVideoElement, canvas: HTMLCanvasElement, context: CanvasRenderingContext2D) => {
    if (video.readyState === video.HAVE_ENOUGH_DATA) {
      // Set canvas dimensions to match video
      canvas.height = video.videoHeight
      canvas.width = video.videoWidth

      // Draw video frame to canvas
      context.drawImage(video, 0, 0, canvas.width, canvas.height)

      // Get image data for QR code detection
      const imageData = context.getImageData(0, 0, canvas.width, canvas.height)

      try {
        // Attempt to detect QR code
        const code = jsQR(imageData.data, imageData.width, imageData.height, {
          inversionAttempts: "dontInvert",
        })

        if (code) {
          // Draw QR code location
          context.beginPath()
          context.moveTo(code.location.topLeftCorner.x, code.location.topLeftCorner.y)
          context.lineTo(code.location.topRightCorner.x, code.location.topRightCorner.y)
          context.lineTo(code.location.bottomRightCorner.x, code.location.bottomRightCorner.y)
          context.lineTo(code.location.bottomLeftCorner.x, code.location.bottomLeftCorner.y)
          context.lineTo(code.location.topLeftCorner.x, code.location.topLeftCorner.y)
          context.lineWidth = 4
          context.strokeStyle = "#3cefff"
          context.stroke()

          // Validate and process QR code data
          try {
            const data = JSON.parse(code.data)
            setLastResult(code.data)
            onResult?.(code.data)
            return true
          } catch (error) {
            console.warn("Invalid QR code data:", error)
          }
        }
      } catch (error) {
        console.error("QR processing error:", error)
        onError?.(error as Error)
      }
    }
    return false
  }

  const startScanning = (videoElement: HTMLVideoElement) => {
    if (!canvasRef.current) {
      canvasRef.current = document.createElement("canvas")
    }

    const canvas = canvasRef.current
    const context = canvas.getContext("2d")

    if (!context) {
      onError?.(new Error("Could not get canvas context"))
      return
    }

    setIsScanning(true)
    setLastResult(null)

    // Clear any existing interval
    if (scanIntervalRef.current) {
      clearInterval(scanIntervalRef.current)
    }

    // Start scanning interval
    scanIntervalRef.current = window.setInterval(() => {
      if (!isScanning) return

      const success = processVideoFrame(videoElement, canvas, context)
      if (success) {
        stopScanning()
      }
    }, 100)
  }

  const stopScanning = () => {
    setIsScanning(false)
    if (scanIntervalRef.current) {
      clearInterval(scanIntervalRef.current)
      scanIntervalRef.current = null
    }
  }

  useEffect(() => {
    return () => {
      if (scanIntervalRef.current) {
        clearInterval(scanIntervalRef.current)
      }
    }
  }, [])

  return {
    isScanning,
    lastResult,
    startScanning,
    stopScanning,
  }
}

