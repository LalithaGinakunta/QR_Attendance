"use client"

import { useState, useEffect } from "react"

interface UseLocationOptions {
  onLocation?: (position: GeolocationPosition) => void
  onError?: (error: GeolocationError) => void
  watchPosition?: boolean
}

export function useLocation({ onLocation, onError, watchPosition = false }: UseLocationOptions = {}) {
  const [position, setPosition] = useState<GeolocationPosition | null>(null)
  const [error, setError] = useState<GeolocationError | null>(null)
  const [isWatching, setIsWatching] = useState(false)

  const handleSuccess = (position: GeolocationPosition) => {
    setPosition(position)
    setError(null)
    onLocation?.(position)
  }

  const handleError = (error: GeolocationError) => {
    setError(error)
    onError?.(error)
  }

  const startWatching = () => {
    if (!navigator.geolocation) {
      const error = new Error("Geolocation is not supported by your browser") as GeolocationError
      setError(error)
      onError?.(error)
      return
    }

    setIsWatching(true)

    if (watchPosition) {
      return navigator.geolocation.watchPosition(handleSuccess, handleError, {
        enableHighAccuracy: true,
        timeout: 5000,
        maximumAge: 0,
      })
    } else {
      navigator.geolocation.getCurrentPosition(handleSuccess, handleError, {
        enableHighAccuracy: true,
        timeout: 5000,
        maximumAge: 0,
      })
      return undefined
    }
  }

  const stopWatching = (watchId?: number) => {
    setIsWatching(false)
    if (watchId !== undefined) {
      navigator.geolocation.clearWatch(watchId)
    }
  }

  useEffect(() => {
    let watchId: number | undefined

    if (watchPosition) {
      watchId = startWatching()
    }

    return () => {
      if (watchId !== undefined) {
        stopWatching(watchId)
      }
    }
  }, [watchPosition])

  return {
    position,
    error,
    isWatching,
    startWatching,
    stopWatching,
  }
}

