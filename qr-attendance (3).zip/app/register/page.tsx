"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { QRCodeCanvas } from "qrcode.react"
import { saveEmployee } from "@/lib/actions"
import {
  UserPlus,
  Download,
  Printer,
  Copy,
  Trash2,
  Edit,
  Plus,
  Check,
  X,
  Upload,
  FileSpreadsheet,
  QrCode,
} from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

type Employee = {
  id: string
  name: string
  department: string
}

export default function RegisterPage() {
  const [employee, setEmployee] = useState<Employee>({
    name: "",
    id: "",
    department: "",
  })
  const [employees, setEmployees] = useState<Employee[]>([])
  const [qrCodeData, setQrCodeData] = useState<string | null>(null)
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [activeTab, setActiveTab] = useState("single")
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null)
  const [bulkEmployees, setBulkEmployees] = useState<string>("")
  const [showSuccessAnimation, setShowSuccessAnimation] = useState(false)

  const fileInputRef = useRef<HTMLInputElement>(null)

  // Load sample employees for demo
  useEffect(() => {
    const sampleEmployees = [
      { id: "EMP001", name: "John Doe", department: "engineering" },
      { id: "EMP002", name: "Jane Smith", department: "marketing" },
      { id: "EMP003", name: "Robert Johnson", department: "finance" },
    ]
    setEmployees(sampleEmployees)
  }, [])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setEmployee((prev) => ({ ...prev, [name]: value }))
  }

  const handleDepartmentChange = (value: string) => {
    setEmployee((prev) => ({ ...prev, department: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      // Generate QR code data
      const qrData = JSON.stringify({
        id: employee.id,
        name: employee.name,
        department: employee.department,
      })

      // Save employee data
      await saveEmployee(employee)

      // Add to employees list
      setEmployees((prev) => [...prev, { ...employee }])

      // Display QR code
      setQrCodeData(qrData)
      setSelectedEmployee(employee)

      // Show success animation
      setShowSuccessAnimation(true)
      setTimeout(() => setShowSuccessAnimation(false), 2000)
    } catch (error) {
      console.error("Error registering employee:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleReset = () => {
    setEmployee({ name: "", id: "", department: "" })
    setQrCodeData(null)
    setSelectedEmployee(null)
    setEditingEmployee(null)
  }

  const handleSelectEmployee = (emp: Employee) => {
    setSelectedEmployee(emp)
    const qrData = JSON.stringify({
      id: emp.id,
      name: emp.name,
      department: emp.department,
    })
    setQrCodeData(qrData)
  }

  const handleEditEmployee = (emp: Employee) => {
    setEditingEmployee(emp)
    setEmployee(emp)
  }

  const handleDeleteEmployee = (empId: string) => {
    setEmployees((prev) => prev.filter((e) => e.id !== empId))
    if (selectedEmployee?.id === empId) {
      setSelectedEmployee(null)
      setQrCodeData(null)
    }
  }

  const handleBulkImport = () => {
    try {
      // Parse CSV-like format (name,id,department)
      const newEmployees = bulkEmployees
        .split("\n")
        .filter((line) => line.trim())
        .map((line) => {
          const [name, id, department] = line.split(",").map((item) => item.trim())
          return { name, id, department }
        })
        .filter((emp) => emp.name && emp.id && emp.department)

      // Add to employees list
      setEmployees((prev) => [...prev, ...newEmployees])
      setBulkEmployees("")

      // Show success animation
      setShowSuccessAnimation(true)
      setTimeout(() => setShowSuccessAnimation(false), 2000)
    } catch (error) {
      console.error("Error importing employees:", error)
    }
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (event) => {
      const content = event.target?.result as string
      setBulkEmployees(content)
    }
    reader.readAsText(file)
  }

  const downloadQRCode = () => {
    const canvas = document.getElementById("qr-canvas") as HTMLCanvasElement
    if (canvas) {
      const pngUrl = canvas.toDataURL("image/png").replace("image/png", "image/octet-stream")
      const downloadLink = document.createElement("a")
      downloadLink.href = pngUrl
      downloadLink.download = `${selectedEmployee?.id || employee.id}_qrcode.png`
      document.body.appendChild(downloadLink)
      downloadLink.click()
      document.body.removeChild(downloadLink)
    }
  }

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold gradient-heading">Employee Registration</h1>
        <UserPlus className="h-8 w-8 text-primary" />
      </div>

      <Tabs defaultValue="single" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="mb-6 rounded-full p-1">
          <TabsTrigger value="single" className="rounded-full">
            Single Registration
          </TabsTrigger>
          <TabsTrigger value="bulk" className="rounded-full">
            Bulk Import
          </TabsTrigger>
          <TabsTrigger value="employees" className="rounded-full">
            Employee Directory
          </TabsTrigger>
        </TabsList>

        <TabsContent value="single">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="glass-card">
              <CardHeader>
                <CardTitle>{editingEmployee ? "Edit Employee" : "Register New Employee"}</CardTitle>
                <CardDescription>
                  {editingEmployee ? "Update employee details" : "Enter employee details to generate a unique QR code"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Employee Name</Label>
                    <Input
                      id="name"
                      name="name"
                      value={employee.name}
                      onChange={handleChange}
                      placeholder="John Doe"
                      required
                      className="rounded-lg transition-all focus:ring-2 focus:ring-primary/50"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="id">Employee ID</Label>
                    <Input
                      id="id"
                      name="id"
                      value={employee.id}
                      onChange={handleChange}
                      placeholder="EMP001"
                      required
                      className="rounded-lg transition-all focus:ring-2 focus:ring-primary/50"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="department">Department</Label>
                    <Select value={employee.department} onValueChange={handleDepartmentChange} required>
                      <SelectTrigger className="rounded-lg transition-all focus:ring-2 focus:ring-primary/50">
                        <SelectValue placeholder="Select department" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="engineering">Engineering</SelectItem>
                        <SelectItem value="marketing">Marketing</SelectItem>
                        <SelectItem value="finance">Finance</SelectItem>
                        <SelectItem value="hr">Human Resources</SelectItem>
                        <SelectItem value="operations">Operations</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex gap-2 pt-4">
                    <Button type="submit" disabled={isSubmitting} className="rounded-full animated-gradient-btn">
                      {isSubmitting ? "Processing..." : editingEmployee ? "Update Employee" : "Register & Generate QR"}
                    </Button>
                    <Button type="button" variant="outline" onClick={handleReset} className="rounded-full">
                      Reset
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>

            <Card className="glass-card">
              <CardHeader>
                <CardTitle>Employee QR Code</CardTitle>
                <CardDescription>Scan this QR code for attendance check-in/out</CardDescription>
              </CardHeader>
              <CardContent className="flex flex-col items-center justify-center min-h-[250px]">
                <AnimatePresence>
                  {showSuccessAnimation && (
                    <motion.div
                      initial={{ scale: 0.5, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      exit={{ scale: 0.5, opacity: 0 }}
                      className="absolute inset-0 flex items-center justify-center bg-primary/10 backdrop-blur-sm rounded-lg z-10"
                    >
                      <motion.div
                        initial={{ scale: 0.5 }}
                        animate={{ scale: 1 }}
                        transition={{ type: "spring", stiffness: 200, damping: 10 }}
                        className="bg-white p-6 rounded-full"
                      >
                        <Check className="h-16 w-16 text-green-500" />
                      </motion.div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {qrCodeData ? (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                    className="text-center"
                  >
                    <div className="bg-white p-4 rounded-lg inline-block mb-4 shadow-lg hover:shadow-xl transition-shadow">
                      <QRCodeCanvas
                        id="qr-canvas"
                        value={qrCodeData}
                        size={200}
                        level="H"
                        includeMargin
                        bgColor="#FFFFFF"
                        fgColor="#6b46c1"
                      />
                    </div>
                    <p className="text-sm text-muted-foreground">Employee ID: {selectedEmployee?.id || employee.id}</p>
                    <p className="text-sm font-medium">{selectedEmployee?.name || employee.name}</p>
                    <p className="text-xs text-muted-foreground capitalize">
                      {selectedEmployee?.department || employee.department}
                    </p>
                  </motion.div>
                ) : (
                  <div className="text-center text-muted-foreground">
                    <div className="bg-secondary p-8 rounded-lg inline-block mb-4">
                      <UserPlus className="h-16 w-16 text-primary/50 mx-auto" />
                    </div>
                    <p>No QR code generated yet</p>
                    <p className="text-sm">Complete the registration form to generate a QR code</p>
                  </div>
                )}
              </CardContent>
              {qrCodeData && (
                <CardFooter className="flex justify-center gap-2">
                  <Button variant="outline" onClick={() => window.print()} className="rounded-full">
                    <Printer className="mr-2 h-4 w-4" />
                    Print
                  </Button>
                  <Button variant="outline" onClick={downloadQRCode} className="rounded-full">
                    <Download className="mr-2 h-4 w-4" />
                    Download
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => navigator.clipboard.writeText(qrCodeData)}
                    className="rounded-full"
                  >
                    <Copy className="mr-2 h-4 w-4" />
                    Copy Data
                  </Button>
                </CardFooter>
              )}
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="bulk">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle>Bulk Employee Import</CardTitle>
              <CardDescription>Import multiple employees at once using CSV format</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="bg-secondary/50 p-4 rounded-lg">
                  <h3 className="text-sm font-medium mb-2">Format Instructions</h3>
                  <p className="text-sm text-muted-foreground mb-2">
                    Enter one employee per line in the format: <span className="font-mono">Name, ID, Department</span>
                  </p>
                  <div className="bg-background p-2 rounded font-mono text-xs">
                    John Doe, EMP001, engineering
                    <br />
                    Jane Smith, EMP002, marketing
                    <br />
                    Robert Johnson, EMP003, finance
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bulk-import">Employee Data</Label>
                  <textarea
                    id="bulk-import"
                    value={bulkEmployees}
                    onChange={(e) => setBulkEmployees(e.target.value)}
                    placeholder="Name, ID, Department (one per line)"
                    className="w-full min-h-[200px] rounded-lg border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2"
                  />
                </div>

                <div className="flex flex-col sm:flex-row gap-4">
                  <Button
                    onClick={handleBulkImport}
                    className="rounded-full animated-gradient-btn"
                    disabled={!bulkEmployees.trim()}
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Import Employees
                  </Button>

                  <Button variant="outline" className="rounded-full" onClick={() => fileInputRef.current?.click()}>
                    <Upload className="mr-2 h-4 w-4" />
                    Upload CSV File
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".csv,.txt"
                      className="hidden"
                      onChange={handleFileUpload}
                    />
                  </Button>

                  <Button variant="outline" className="rounded-full" onClick={() => setBulkEmployees("")}>
                    <X className="mr-2 h-4 w-4" />
                    Clear
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="employees">
          <Card className="glass-card">
            <CardHeader>
              <CardTitle>Employee Directory</CardTitle>
              <CardDescription>View and manage all registered employees</CardDescription>
            </CardHeader>
            <CardContent>
              {employees.length > 0 ? (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead>Department</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {employees.map((emp) => (
                        <TableRow key={emp.id} className={selectedEmployee?.id === emp.id ? "bg-primary/5" : ""}>
                          <TableCell className="font-medium">{emp.id}</TableCell>
                          <TableCell>{emp.name}</TableCell>
                          <TableCell className="capitalize">{emp.department}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleSelectEmployee(emp)}
                                className="h-8 w-8 rounded-full hover:bg-primary/10"
                              >
                                <QrCode className="h-4 w-4" />
                                <span className="sr-only">Generate QR</span>
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleEditEmployee(emp)}
                                className="h-8 w-8 rounded-full hover:bg-primary/10"
                              >
                                <Edit className="h-4 w-4" />
                                <span className="sr-only">Edit</span>
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleDeleteEmployee(emp.id)}
                                className="h-8 w-8 rounded-full hover:bg-destructive/10"
                              >
                                <Trash2 className="h-4 w-4 text-destructive" />
                                <span className="sr-only">Delete</span>
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="text-center py-12">
                  <FileSpreadsheet className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">No employees registered yet</p>
                  <Button onClick={() => setActiveTab("single")} variant="outline" className="mt-4 rounded-full">
                    Register New Employee
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

