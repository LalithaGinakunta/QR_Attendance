import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import Image from "next/image"
import { Clock, QrCode, UserPlus, BarChart3, Shield, MapPin } from "lucide-react"

export default function Home() {
  return (
    <div className="space-y-8">
      <div className="text-center space-y-6 py-16">
        <div className="flex justify-center mb-8">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Beige%20and%20Black%20Minimalist%20Qr%20Code%20Business%20Square%20Sticker-gJd07Mr8UTIOqY9NJZGOJNWuN7buAi.png"
            alt="QR Presence Logo"
            width={180}
            height={180}
            className="object-contain"
          />
        </div>
        <h1 className="text-5xl font-bold tracking-tight gradient-heading">QR Presence</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Your QR, Your Security - A secure attendance tracking system with facial recognition and geolocation
          verification
        </p>
        <div className="flex flex-wrap gap-4 justify-center mt-6">
          <Button asChild size="lg" className="rounded-full animated-gradient-btn">
            <Link href="/register">Get Started</Link>
          </Button>
          <Button asChild size="lg" variant="outline" className="rounded-full">
            <Link href="/dashboard">View Dashboard</Link>
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="glass-card card-hover">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2">
              <div className="bg-secondary p-2 rounded-full">
                <UserPlus className="h-5 w-5 text-primary" />
              </div>
              Employee Registration
            </CardTitle>
            <CardDescription>Register new employees and generate QR codes</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="mb-4 text-muted-foreground">
              Add new employees to the system and generate unique QR codes for attendance tracking.
            </p>
            <Button asChild className="w-full rounded-full animated-gradient-btn">
              <Link href="/register">Register Employees</Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="glass-card card-hover">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2">
              <div className="bg-secondary p-2 rounded-full">
                <QrCode className="h-5 w-5 text-primary" />
              </div>
              Scan QR Code
            </CardTitle>
            <CardDescription>Check-in and check-out with QR codes</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="mb-4 text-muted-foreground">
              Scan employee QR codes to record attendance for check-ins and check-outs.
            </p>
            <Button asChild className="w-full rounded-full animated-gradient-btn">
              <Link href="/scan">Scan QR Code</Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="glass-card card-hover">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2">
              <div className="bg-secondary p-2 rounded-full">
                <BarChart3 className="h-5 w-5 text-primary" />
              </div>
              Admin Dashboard
            </CardTitle>
            <CardDescription>View attendance reports and logs</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="mb-4 text-muted-foreground">
              Access attendance data, including late check-ins, early check-outs, and absentees.
            </p>
            <Button asChild className="w-full rounded-full animated-gradient-btn">
              <Link href="/dashboard">View Dashboard</Link>
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="mt-16">
        <Card className="glass-card overflow-hidden border-0">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-8 flex flex-col justify-center">
              <h2 className="text-3xl font-bold mb-4 gradient-heading">Advanced Security Features</h2>
              <p className="text-muted-foreground mb-6">
                Our system combines QR code scanning with facial recognition and geolocation verification to prevent
                proxy attendance and ensure security.
              </p>
              <ul className="space-y-3">
                <li className="flex items-start gap-2">
                  <div className="bg-secondary p-1 rounded-full mt-0.5">
                    <Shield className="h-4 w-4 text-primary" />
                  </div>
                  <span>Facial recognition verification prevents proxy attendance</span>
                </li>
                <li className="flex items-start gap-2">
                  <div className="bg-secondary p-1 rounded-full mt-0.5">
                    <MapPin className="h-4 w-4 text-primary" />
                  </div>
                  <span>Geolocation validation ensures employees are at the correct location</span>
                </li>
                <li className="flex items-start gap-2">
                  <div className="bg-secondary p-1 rounded-full mt-0.5">
                    <Clock className="h-4 w-4 text-primary" />
                  </div>
                  <span>Real-time verification with tamper-proof logging</span>
                </li>
              </ul>
              <Button asChild className="mt-6 rounded-full animated-gradient-btn">
                <Link href="/security">Security Settings</Link>
              </Button>
            </div>
            <div className="bg-gradient-to-br from-primary to-accent p-8 flex items-center justify-center">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Beige%20and%20Black%20Minimalist%20Qr%20Code%20Business%20Square%20Sticker-gJd07Mr8UTIOqY9NJZGOJNWuN7buAi.png"
                alt="QR Presence Security Features"
                width={300}
                height={300}
                className="rounded-lg shadow-lg max-w-full h-auto"
              />
            </div>
          </div>
        </Card>
      </div>
    </div>
  )
}

