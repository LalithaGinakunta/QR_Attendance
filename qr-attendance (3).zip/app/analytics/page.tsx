"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format, addDays, subDays, startOfMonth, endOfMonth } from "date-fns"
import { CalendarIcon, TrendingUp, AlertTriangle, UserCheck, Clock, Download } from "lucide-react"
import { cn } from "@/lib/utils"
import { getAttendanceRecords } from "@/lib/actions"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts"

export default function AnalyticsPage() {
  const [dateRange, setDateRange] = useState<{
    from: Date
    to: Date
  }>({
    from: startOfMonth(new Date()),
    to: endOfMonth(new Date()),
  })
  const [department, setDepartment] = useState<string>("all")
  const [attendanceData, setAttendanceData] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [predictions, setPredictions] = useState<any[]>([])

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true)
      try {
        const records = await getAttendanceRecords({
          dateRange: {
            from: format(dateRange.from, "yyyy-MM-dd"),
            to: format(dateRange.to, "yyyy-MM-dd"),
          },
          department: department !== "all" ? department : undefined,
        })
        setAttendanceData(records)

        // Generate mock predictions
        generatePredictions(records)
      } catch (error) {
        console.error("Error fetching attendance data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [dateRange, department])

  const generatePredictions = (records: any[]) => {
    // This would be a real ML model in production
    // For demo, we'll create some mock predictions

    // Find employees with attendance patterns
    const employeeAttendance: Record<string, any[]> = {}

    records.forEach((record) => {
      if (!employeeAttendance[record.employeeId]) {
        employeeAttendance[record.employeeId] = []
      }
      employeeAttendance[record.employeeId].push(record)
    })

    const predictedIssues = []

    // Identify employees with late check-ins
    for (const [employeeId, records] of Object.entries(employeeAttendance)) {
      const lateCheckIns = records.filter((r) => r.isLate).length
      const totalCheckIns = records.filter((r) => r.type === "check-in").length

      if (lateCheckIns > 0 && lateCheckIns / totalCheckIns > 0.3) {
        // More than 30% late check-ins
        const employee = records[0]
        predictedIssues.push({
          id: employeeId,
          name: employee.employeeName,
          department: employee.department,
          issue: "frequent_late",
          probability: Math.min(0.5 + lateCheckIns / totalCheckIns, 0.95),
          message: "Frequently arrives late",
          nextDate: format(addDays(new Date(), Math.floor(Math.random() * 5) + 1), "yyyy-MM-dd"),
        })
      }

      // Check for absence patterns (e.g., Mondays)
      const checkInDates = records.filter((r) => r.type === "check-in").map((r) => new Date(r.timestamp))

      const dayOfWeekCounts = [0, 0, 0, 0, 0, 0, 0] // Sun-Sat

      checkInDates.forEach((date) => {
        dayOfWeekCounts[date.getDay()]++
      })

      const minAttendanceDay = dayOfWeekCounts.indexOf(Math.min(...dayOfWeekCounts.filter((c) => c > 0)))

      if (minAttendanceDay !== -1 && dayOfWeekCounts[minAttendanceDay] < Math.max(...dayOfWeekCounts) * 0.7) {
        const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
        const employee = records[0]

        predictedIssues.push({
          id: employeeId,
          name: employee.employeeName,
          department: employee.department,
          issue: "day_pattern",
          probability: 0.7 + Math.random() * 0.2,
          message: `Tends to be absent on ${dayNames[minAttendanceDay]}s`,
          nextDate: format(addDays(new Date(), (minAttendanceDay - new Date().getDay() + 7) % 7), "yyyy-MM-dd"),
        })
      }
    }

    setPredictions(predictedIssues)
  }

  // Prepare data for charts
  const attendanceTrendData = Array.from({ length: 30 }, (_, i) => {
    const date = subDays(new Date(), 29 - i)
    const dateStr = format(date, "MMM dd")

    const checkIns = Math.floor(Math.random() * 5) + 20
    const lateCheckIns = Math.floor(Math.random() * 5)
    const absences = 25 - checkIns

    return {
      date: dateStr,
      checkIns,
      lateCheckIns,
      absences,
    }
  })

  const departmentAttendanceData = [
    { name: "Engineering", onTime: 92, late: 5, absent: 3 },
    { name: "Marketing", onTime: 88, late: 7, absent: 5 },
    { name: "Finance", onTime: 95, late: 3, absent: 2 },
    { name: "HR", onTime: 90, late: 6, absent: 4 },
    { name: "Operations", onTime: 85, late: 10, absent: 5 },
  ]

  const timeDistributionData = [
    { time: "8:00-8:30", count: 15 },
    { time: "8:30-9:00", count: 35 },
    { time: "9:00-9:30", count: 25 },
    { time: "9:30-10:00", count: 15 },
    { time: "After 10:00", count: 10 },
  ]

  const COLORS = ["#4f46e5", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6"]

  const handleExport = () => {
    // In a real app, this would generate a CSV file
    alert("Export functionality would be implemented here")
  }

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6 gap-4">
        <div className="flex items-center gap-3">
          <TrendingUp className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold gradient-heading">Predictive Analytics</h1>
        </div>
        <Button onClick={handleExport} className="rounded-full animated-gradient-btn">
          <Download className="mr-2 h-4 w-4" />
          Export Report
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <Card className="dashboard-card col-span-1 lg:col-span-2">
          <CardHeader>
            <CardTitle>Attendance Predictions</CardTitle>
            <CardDescription>AI-powered predictions based on historical attendance patterns</CardDescription>
          </CardHeader>
          <CardContent>
            {predictions.length > 0 ? (
              <div className="space-y-4">
                {predictions.map((prediction, index) => (
                  <Alert
                    key={index}
                    className={cn(
                      "border-l-4",
                      prediction.probability > 0.8
                        ? "border-l-red-500 bg-red-50 dark:bg-red-900/20"
                        : "border-l-amber-500 bg-amber-50 dark:bg-amber-900/20",
                    )}
                  >
                    <AlertTriangle
                      className={cn("h-4 w-4", prediction.probability > 0.8 ? "text-red-500" : "text-amber-500")}
                    />
                    <AlertTitle className="flex items-center justify-between">
                      <span>
                        {prediction.name} ({prediction.id})
                      </span>
                      <span
                        className={cn(
                          "text-xs px-2 py-1 rounded-full",
                          prediction.probability > 0.8
                            ? "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300"
                            : "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300",
                        )}
                      >
                        {Math.round(prediction.probability * 100)}% probability
                      </span>
                    </AlertTitle>
                    <AlertDescription className="mt-2">
                      <p>{prediction.message}</p>
                      <p className="text-sm mt-1">
                        <span className="font-medium">Predicted next occurrence:</span>{" "}
                        {format(new Date(prediction.nextDate), "EEEE, MMMM d, yyyy")}
                      </p>
                    </AlertDescription>
                  </Alert>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <AlertTriangle className="h-12 w-12 mx-auto mb-3 text-muted-foreground/50" />
                <p>No attendance issues predicted at this time.</p>
                <p className="text-sm mt-1">Continue monitoring for potential patterns.</p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="dashboard-card">
          <CardHeader>
            <CardTitle>Filters</CardTitle>
            <CardDescription>Adjust date range and department</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Date Range</Label>
                <div className={cn("grid gap-2", "grid-cols-2")}>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        id="from"
                        variant={"outline"}
                        className={cn(
                          "w-full justify-start text-left font-normal rounded-lg",
                          !dateRange.from && "text-muted-foreground",
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {dateRange.from ? format(dateRange.from, "PPP") : <span>Pick a date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        initialFocus
                        mode="single"
                        selected={dateRange.from}
                        onSelect={(date) => setDateRange((prev) => ({ ...prev, from: date || prev.from }))}
                      />
                    </PopoverContent>
                  </Popover>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        id="to"
                        variant={"outline"}
                        className={cn(
                          "w-full justify-start text-left font-normal rounded-lg",
                          !dateRange.to && "text-muted-foreground",
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {dateRange.to ? format(dateRange.to, "PPP") : <span>Pick a date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        initialFocus
                        mode="single"
                        selected={dateRange.to}
                        onSelect={(date) => setDateRange((prev) => ({ ...prev, to: date || prev.to }))}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="department">Department</Label>
                <Select value={department} onValueChange={setDepartment}>
                  <SelectTrigger className="rounded-lg">
                    <SelectValue placeholder="Select department" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Departments</SelectItem>
                    <SelectItem value="engineering">Engineering</SelectItem>
                    <SelectItem value="marketing">Marketing</SelectItem>
                    <SelectItem value="finance">Finance</SelectItem>
                    <SelectItem value="hr">Human Resources</SelectItem>
                    <SelectItem value="operations">Operations</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="pt-4">
                <Button className="w-full rounded-full animated-gradient-btn">Generate Predictions</Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="trends" className="w-full">
        <TabsList className="mb-4 rounded-full p-1">
          <TabsTrigger value="trends" className="rounded-full">
            Attendance Trends
          </TabsTrigger>
          <TabsTrigger value="departments" className="rounded-full">
            Department Analysis
          </TabsTrigger>
          <TabsTrigger value="patterns" className="rounded-full">
            Time Patterns
          </TabsTrigger>
        </TabsList>

        <TabsContent value="trends">
          <Card className="dashboard-card">
            <CardHeader>
              <CardTitle>30-Day Attendance Trend</CardTitle>
              <CardDescription>Historical attendance data with trend analysis</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={attendanceTrendData}
                    margin={{
                      top: 5,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="checkIns" stroke="#4f46e5" activeDot={{ r: 8 }} name="On Time" />
                    <Line type="monotone" dataKey="lateCheckIns" stroke="#f59e0b" name="Late" />
                    <Line type="monotone" dataKey="absences" stroke="#ef4444" name="Absent" />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-center gap-2 p-4 bg-blue-50 rounded-lg dark:bg-blue-900/20">
                  <UserCheck className="h-8 w-8 text-blue-600 dark:text-blue-400" />
                  <div>
                    <div className="text-sm font-medium">Average Attendance</div>
                    <div className="text-2xl font-bold">92%</div>
                  </div>
                </div>

                <div className="flex items-center gap-2 p-4 bg-amber-50 rounded-lg dark:bg-amber-900/20">
                  <Clock className="h-8 w-8 text-amber-600 dark:text-amber-400" />
                  <div>
                    <div className="text-sm font-medium">Late Arrivals</div>
                    <div className="text-2xl font-bold">5.8%</div>
                  </div>
                </div>

                <div className="flex items-center gap-2 p-4 bg-red-50 rounded-lg dark:bg-red-900/20">
                  <AlertTriangle className="h-8 w-8 text-red-600 dark:text-red-400" />
                  <div>
                    <div className="text-sm font-medium">Absence Rate</div>
                    <div className="text-2xl font-bold">2.2%</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="departments">
          <Card className="dashboard-card">
            <CardHeader>
              <CardTitle>Department Attendance Analysis</CardTitle>
              <CardDescription>Comparative attendance metrics across departments</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={departmentAttendanceData}
                    margin={{
                      top: 20,
                      right: 30,
                      left: 20,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="onTime" stackId="a" fill="#4f46e5" name="On Time" />
                    <Bar dataKey="late" stackId="a" fill="#f59e0b" name="Late" />
                    <Bar dataKey="absent" stackId="a" fill="#ef4444" name="Absent" />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              <div className="mt-6">
                <h3 className="text-lg font-medium mb-2">Key Insights</h3>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <div className="bg-green-100 p-1 rounded-full mt-0.5">
                      <UserCheck className="h-4 w-4 text-green-600" />
                    </div>
                    <span>Finance department has the highest on-time attendance rate at 95%</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="bg-amber-100 p-1 rounded-full mt-0.5">
                      <Clock className="h-4 w-4 text-amber-600" />
                    </div>
                    <span>Operations department has the highest late arrival rate at 10%</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="bg-blue-100 p-1 rounded-full mt-0.5">
                      <TrendingUp className="h-4 w-4 text-blue-600" />
                    </div>
                    <span>Engineering department shows improving attendance trends over the last month</span>
                  </li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="patterns">
          <Card className="dashboard-card">
            <CardHeader>
              <CardTitle>Check-in Time Distribution</CardTitle>
              <CardDescription>Analysis of when employees typically arrive</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={timeDistributionData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="count"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {timeDistributionData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>

                <div className="flex flex-col justify-center">
                  <h3 className="text-lg font-medium mb-4">Time Pattern Insights</h3>
                  <div className="space-y-4">
                    <div className="p-4 bg-blue-50 rounded-lg dark:bg-blue-900/20">
                      <h4 className="font-medium mb-1">Peak Arrival Time</h4>
                      <p className="text-sm text-muted-foreground">
                        The majority of employees (35%) arrive between 8:30 AM and 9:00 AM, which is within the expected
                        arrival window.
                      </p>
                    </div>

                    <div className="p-4 bg-amber-50 rounded-lg dark:bg-amber-900/20">
                      <h4 className="font-medium mb-1">Late Arrival Pattern</h4>
                      <p className="text-sm text-muted-foreground">
                        Approximately 25% of employees arrive after 9:00 AM, with 10% arriving after 10:00 AM, which is
                        considered late.
                      </p>
                    </div>

                    <div className="p-4 bg-green-50 rounded-lg dark:bg-green-900/20">
                      <h4 className="font-medium mb-1">Early Birds</h4>
                      <p className="text-sm text-muted-foreground">
                        15% of employees arrive before 8:30 AM, showing exceptional punctuality and dedication.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

