"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Shield, MapPin, User, AlertTriangle, Lock, Eye, Settings, QrCode } from "lucide-react"

export default function SecurityPage() {
  const [faceVerification, setFaceVerification] = useState(true)
  const [locationVerification, setLocationVerification] = useState(true)
  const [faceMatchThreshold, setFaceMatchThreshold] = useState(80)
  const [locationRadius, setLocationRadius] = useState(100)
  const [securityLevel, setSecurityLevel] = useState("high")

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Shield className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold gradient-heading">Security Settings</h1>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <Card className="dashboard-card col-span-1 lg:col-span-2">
          <CardHeader>
            <CardTitle>Security Configuration</CardTitle>
            <CardDescription>Configure security settings for attendance verification</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="verification" className="w-full">
              <TabsList className="mb-4 rounded-full p-1">
                <TabsTrigger value="verification" className="rounded-full">
                  Verification Methods
                </TabsTrigger>
                <TabsTrigger value="locations" className="rounded-full">
                  Approved Locations
                </TabsTrigger>
                <TabsTrigger value="logs" className="rounded-full">
                  Security Logs
                </TabsTrigger>
              </TabsList>

              <TabsContent value="verification">
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <div className="flex items-center">
                        <User className="mr-2 h-4 w-4 text-primary" />
                        <Label htmlFor="face-verification" className="font-medium">
                          Facial Recognition
                        </Label>
                      </div>
                      <p className="text-sm text-muted-foreground">Require facial verification for attendance</p>
                    </div>
                    <Switch id="face-verification" checked={faceVerification} onCheckedChange={setFaceVerification} />
                  </div>

                  {faceVerification && (
                    <div className="pl-6 border-l-2 border-muted space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="face-threshold">Face Match Threshold ({faceMatchThreshold}%)</Label>
                        <Slider
                          id="face-threshold"
                          min={50}
                          max={99}
                          step={1}
                          value={[faceMatchThreshold]}
                          onValueChange={(value) => setFaceMatchThreshold(value[0])}
                        />
                        <p className="text-xs text-muted-foreground">
                          Higher values provide more security but may increase false rejections
                        </p>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="face-action">On Failed Verification</Label>
                        <Select defaultValue="block">
                          <SelectTrigger id="face-action" className="rounded-lg">
                            <SelectValue placeholder="Select action" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="block">Block Attendance</SelectItem>
                            <SelectItem value="warn">Allow with Warning</SelectItem>
                            <SelectItem value="notify">Notify Administrator</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-4 border-t">
                    <div className="space-y-0.5">
                      <div className="flex items-center">
                        <MapPin className="mr-2 h-4 w-4 text-primary" />
                        <Label htmlFor="location-verification" className="font-medium">
                          Geolocation Verification
                        </Label>
                      </div>
                      <p className="text-sm text-muted-foreground">Verify employee location during attendance</p>
                    </div>
                    <Switch
                      id="location-verification"
                      checked={locationVerification}
                      onCheckedChange={setLocationVerification}
                    />
                  </div>

                  {locationVerification && (
                    <div className="pl-6 border-l-2 border-muted space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="location-radius">Allowed Radius ({locationRadius} meters)</Label>
                        <Slider
                          id="location-radius"
                          min={50}
                          max={500}
                          step={10}
                          value={[locationRadius]}
                          onValueChange={(value) => setLocationRadius(value[0])}
                        />
                        <p className="text-xs text-muted-foreground">
                          Maximum distance from office location to allow attendance
                        </p>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="location-action">On Failed Location Check</Label>
                        <Select defaultValue="block">
                          <SelectTrigger id="location-action" className="rounded-lg">
                            <SelectValue placeholder="Select action" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="block">Block Attendance</SelectItem>
                            <SelectItem value="warn">Allow with Warning</SelectItem>
                            <SelectItem value="notify">Notify Administrator</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-4 border-t">
                    <div className="space-y-0.5">
                      <div className="flex items-center">
                        <Lock className="mr-2 h-4 w-4 text-primary" />
                        <Label htmlFor="security-level" className="font-medium">
                          Overall Security Level
                        </Label>
                      </div>
                      <p className="text-sm text-muted-foreground">Configure the system-wide security posture</p>
                    </div>
                    <Select value={securityLevel} onValueChange={setSecurityLevel}>
                      <SelectTrigger id="security-level" className="w-[180px] rounded-lg">
                        <SelectValue placeholder="Select level" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="custom">Custom</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="locations">
                <div className="space-y-4">
                  <div className="rounded-lg border p-4">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h3 className="font-medium">Main Office</h3>
                        <p className="text-sm text-muted-foreground">123 Business Ave, San Francisco, CA</p>
                      </div>
                      <div className="flex items-center">
                        <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full dark:bg-green-900/30 dark:text-green-300 mr-2">
                          Active
                        </span>
                        <Button variant="outline" size="sm" className="rounded-full">
                          Edit
                        </Button>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-xs">Latitude</Label>
                        <Input value="37.7749" readOnly className="bg-muted" />
                      </div>
                      <div>
                        <Label className="text-xs">Longitude</Label>
                        <Input value="-122.4194" readOnly className="bg-muted" />
                      </div>
                    </div>
                  </div>

                  <div className="rounded-lg border p-4">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h3 className="font-medium">Branch Office</h3>
                        <p className="text-sm text-muted-foreground">456 Corporate Blvd, New York, NY</p>
                      </div>
                      <div className="flex items-center">
                        <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full dark:bg-green-900/30 dark:text-green-300 mr-2">
                          Active
                        </span>
                        <Button variant="outline" size="sm" className="rounded-full">
                          Edit
                        </Button>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label className="text-xs">Latitude</Label>
                        <Input value="40.7128" readOnly className="bg-muted" />
                      </div>
                      <div>
                        <Label className="text-xs">Longitude</Label>
                        <Input value="-74.0060" readOnly className="bg-muted" />
                      </div>
                    </div>
                  </div>

                  <Button className="w-full rounded-full animated-gradient-btn">Add New Location</Button>
                </div>
              </TabsContent>

              <TabsContent value="logs">
                <div className="space-y-4">
                  <div className="rounded-lg border p-4">
                    <div className="flex items-start gap-3">
                      <AlertTriangle className="h-5 w-5 text-amber-500 mt-0.5" />
                      <div>
                        <div className="flex items-center justify-between">
                          <h3 className="font-medium">Failed Face Verification</h3>
                          <span className="text-xs text-muted-foreground">Today, 10:23 AM</span>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          Employee ID: EMP001 (John Doe) - Face verification failed with 62% match (below threshold)
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="rounded-lg border p-4">
                    <div className="flex items-start gap-3">
                      <AlertTriangle className="h-5 w-5 text-red-500 mt-0.5" />
                      <div>
                        <div className="flex items-center justify-between">
                          <h3 className="font-medium">Location Verification Failed</h3>
                          <span className="text-xs text-muted-foreground">Yesterday, 9:15 AM</span>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          Employee ID: EMP015 (Jane Smith) - Location was 1.2 km away from approved office location
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="rounded-lg border p-4">
                    <div className="flex items-start gap-3">
                      <Eye className="h-5 w-5 text-primary mt-0.5" />
                      <div>
                        <div className="flex items-center justify-between">
                          <h3 className="font-medium">Security Settings Changed</h3>
                          <span className="text-xs text-muted-foreground">2 days ago, 3:45 PM</span>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          Administrator (admin@company.com) changed face match threshold from 75% to 80%
                        </p>
                      </div>
                    </div>
                  </div>

                  <Button variant="outline" className="w-full rounded-full">
                    View All Security Logs
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        <Card className="dashboard-card">
          <CardHeader>
            <CardTitle>Security Status</CardTitle>
            <CardDescription>Current security configuration status</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div className="text-center p-4 bg-secondary rounded-lg">
                <div className="inline-flex p-3 rounded-full bg-primary/10 mb-3">
                  <Shield className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-lg font-medium">Security Level</h3>
                <div className="text-2xl font-bold mt-1 capitalize">{securityLevel}</div>
                <p className="text-sm text-muted-foreground mt-2">
                  {securityLevel === "high" && "Maximum security with all verification methods enabled"}
                  {securityLevel === "medium" && "Balanced security with essential verification"}
                  {securityLevel === "low" && "Basic security with minimal verification"}
                  {securityLevel === "custom" && "Custom security configuration"}
                </p>
              </div>

              <div className="space-y-4">
                <h3 className="font-medium">Active Security Features</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <User className="h-4 w-4 mr-2 text-primary" />
                      <span className="text-sm">Facial Recognition</span>
                    </div>
                    <span
                      className={`text-xs px-2 py-1 rounded-full ${faceVerification ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300" : "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300"}`}
                    >
                      {faceVerification ? "Enabled" : "Disabled"}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 mr-2 text-primary" />
                      <span className="text-sm">Geolocation Verification</span>
                    </div>
                    <span
                      className={`text-xs px-2 py-1 rounded-full ${locationVerification ? "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300" : "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300"}`}
                    >
                      {locationVerification ? "Enabled" : "Disabled"}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <QrCode className="h-4 w-4 mr-2 text-primary" />
                      <span className="text-sm">QR Code Verification</span>
                    </div>
                    <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full dark:bg-green-900/30 dark:text-green-300">
                      Enabled
                    </span>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t">
                <Button className="w-full rounded-full animated-gradient-btn">
                  <Settings className="mr-2 h-4 w-4" />
                  Apply Changes
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

