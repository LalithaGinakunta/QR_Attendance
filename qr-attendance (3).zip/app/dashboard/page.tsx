"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { format } from "date-fns"
import { CalendarIcon, Download, Filter, UserCheck, UserX, Clock, BarChart3 } from "lucide-react"
import { getAttendanceRecords } from "@/lib/actions"
import AttendanceTable from "@/components/attendance-table"
import AttendanceSummary from "@/components/attendance-summary"

export default function DashboardPage() {
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [department, setDepartment] = useState<string>("all")
  const [searchQuery, setSearchQuery] = useState("")
  const [attendanceData, setAttendanceData] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true)
      try {
        const records = await getAttendanceRecords({
          date: date ? format(date, "yyyy-MM-dd") : undefined,
          department: department !== "all" ? department : undefined,
          searchQuery: searchQuery || undefined,
        })
        setAttendanceData(records)
      } catch (error) {
        console.error("Error fetching attendance data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [date, department, searchQuery])

  const handleExport = () => {
    // In a real app, this would generate a CSV file
    alert("Export functionality would be implemented here")
  }

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6 gap-4">
        <div className="flex items-center gap-3">
          <BarChart3 className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold gradient-heading">Attendance Dashboard</h1>
        </div>
        <Button onClick={handleExport} className="rounded-full animated-gradient-btn">
          <Download className="mr-2 h-4 w-4" />
          Export Data
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card className="dashboard-card stat-card present">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <div className="bg-green-100 p-2 rounded-full">
                <UserCheck className="h-5 w-5 text-green-600" />
              </div>
              Present Today
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {isLoading ? "..." : attendanceData.filter((record) => record.type === "check-in").length}
            </div>
            <p className="text-sm text-muted-foreground">Employees checked in</p>
          </CardContent>
        </Card>

        <Card className="dashboard-card stat-card late">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <div className="bg-amber-100 p-2 rounded-full">
                <Clock className="h-5 w-5 text-amber-600" />
              </div>
              Late Check-ins
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {isLoading ? "..." : attendanceData.filter((record) => record.isLate).length}
            </div>
            <p className="text-sm text-muted-foreground">Employees arrived late</p>
          </CardContent>
        </Card>

        <Card className="dashboard-card stat-card absent">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <div className="bg-red-100 p-2 rounded-full">
                <UserX className="h-5 w-5 text-red-600" />
              </div>
              Absent
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {isLoading ? "..." : 25 - attendanceData.filter((record) => record.type === "check-in").length}
            </div>
            <p className="text-sm text-muted-foreground">Employees not checked in</p>
          </CardContent>
        </Card>
      </div>

      <Card className="mb-6 glass-card">
        <CardHeader>
          <CardTitle>Attendance Filters</CardTitle>
          <CardDescription>Filter attendance records by date, department, or employee</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="date">Date</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left font-normal rounded-lg">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {date ? format(date, "PPP") : "Select date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label htmlFor="department">Department</Label>
              <Select value={department} onValueChange={setDepartment}>
                <SelectTrigger className="rounded-lg">
                  <SelectValue placeholder="Select department" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Departments</SelectItem>
                  <SelectItem value="engineering">Engineering</SelectItem>
                  <SelectItem value="marketing">Marketing</SelectItem>
                  <SelectItem value="finance">Finance</SelectItem>
                  <SelectItem value="hr">Human Resources</SelectItem>
                  <SelectItem value="operations">Operations</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="search">Search Employee</Label>
              <div className="flex gap-2">
                <Input
                  id="search"
                  placeholder="Search by name or ID"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="rounded-lg"
                />
                <Button variant="outline" size="icon" className="rounded-lg">
                  <Filter className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="records" className="w-full">
        <TabsList className="mb-4 rounded-full p-1">
          <TabsTrigger value="records" className="rounded-full">
            Attendance Records
          </TabsTrigger>
          <TabsTrigger value="summary" className="rounded-full">
            Summary Report
          </TabsTrigger>
        </TabsList>

        <TabsContent value="records">
          <AttendanceTable data={attendanceData} isLoading={isLoading} />
        </TabsContent>

        <TabsContent value="summary">
          <AttendanceSummary data={attendanceData} isLoading={isLoading} />
        </TabsContent>
      </Tabs>
    </div>
  )
}

