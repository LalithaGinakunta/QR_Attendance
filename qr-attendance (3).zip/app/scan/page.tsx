"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Tabs, TabsContent } from "@/components/ui/tabs"
import { CheckCircle, AlertCircle, MapPin, User, QrCode, Info } from "lucide-react"
import { logAttendance } from "@/lib/actions"
import { QRScanner } from "@/components/qr-scanner"
import { FaceVerifier } from "@/components/face-verifier"
import { LocationVerifier } from "@/components/location-verifier"
import { ConfettiCelebration } from "@/components/confetti-celebration"
import { FeatureTour } from "@/components/feature-tour"
import { SettingsPanel } from "@/components/settings-panel"
import { ScanHistory } from "@/components/scan-history"
import { useSoundEffects } from "@/lib/hooks/use-sound-effects"
import { motion, AnimatePresence } from "framer-motion"

type AttendanceMode = "check-in" | "check-out"
type VerificationStep = "qr" | "face" | "location" | "complete"

// Tour steps for first-time users
const tourSteps = [
  {
    target: "#mode-selection",
    title: "Select Attendance Mode",
    content: "Choose whether you're checking in or checking out.",
    position: "bottom",
  },
  {
    target: "#qr-scanner",
    title: "Scan QR Code",
    content: "Position the employee's QR code in the scanner frame.",
    position: "top",
  },
  {
    target: "#verification-steps",
    title: "Multi-Factor Verification",
    content: "Complete all verification steps to ensure security.",
    position: "left",
  },
]

export default function ScanPage() {
  // State
  const [attendanceMode, setAttendanceMode] = useState<AttendanceMode>("check-in")
  const [currentStep, setCurrentStep] = useState<VerificationStep>("qr")
  const [verificationProgress, setVerificationProgress] = useState(0)
  const [status, setStatus] = useState<"success" | "error" | null>(null)
  const [message, setMessage] = useState("")
  const [employeeData, setEmployeeData] = useState<any>(null)
  const [showConfetti, setShowConfetti] = useState(false)
  const [showTour, setShowTour] = useState(false)
  const [isFirstVisit, setIsFirstVisit] = useState(false)
  const [isOffline, setIsOffline] = useState(false)

  // Custom hooks
  const { feedback } = useSoundEffects()

  // Check if this is the first visit
  useEffect(() => {
    const hasVisitedBefore = localStorage.getItem("scan-page-visited")
    if (!hasVisitedBefore) {
      setIsFirstVisit(true)
      setShowTour(true)
      localStorage.setItem("scan-page-visited", "true")
    }

    // Check online status
    setIsOffline(!navigator.onLine)

    const handleOnline = () => setIsOffline(false)
    const handleOffline = () => setIsOffline(true)

    window.addEventListener("online", handleOnline)
    window.addEventListener("offline", handleOffline)

    return () => {
      window.removeEventListener("online", handleOnline)
      window.removeEventListener("offline", handleOffline)
    }
  }, [])

  // Handle QR code scan
  const handleQRScan = (data: string) => {
    try {
      // Parse QR code data
      const parsedData = JSON.parse(data)

      // Validate required fields
      if (!parsedData.id || !parsedData.name || !parsedData.department) {
        throw new Error("Invalid QR code format. Missing required employee data.")
      }

      // Store employee data
      setEmployeeData(parsedData)

      // Play success sound and vibrate
      feedback("scan")

      // Move to next step
      setCurrentStep("face")
      setVerificationProgress(33)
    } catch (error) {
      console.error("QR code parsing error:", error)
      setStatus("error")
      setMessage("Invalid QR code. Please scan a valid employee QR code.")

      // Play error sound
      feedback("error")
    }
  }

  // Handle face verification
  const handleFaceVerified = () => {
    setCurrentStep("location")
    setVerificationProgress(66)

    // Play success sound
    feedback("success")
  }

  // Handle location verification
  const handleLocationVerified = () => {
    setCurrentStep("complete")
    setVerificationProgress(100)
    handleAttendanceLog()
  }

  // Handle attendance logging
  const handleAttendanceLog = async () => {
    if (!employeeData) return

    try {
      // Create attendance record
      const attendanceRecord = {
        id: `${Date.now()}-${employeeData.id}`,
        employeeId: employeeData.id,
        employeeName: employeeData.name,
        department: employeeData.department,
        type: attendanceMode,
        timestamp: new Date().toISOString(),
        verificationMethod: "facial+geolocation",
        location: {
          latitude: 37.7749, // Example coordinates
          longitude: -122.4194,
        },
      }

      // If offline, store locally
      if (isOffline) {
        // Store in IndexedDB for later sync
        saveOfflineRecord(attendanceRecord)

        setStatus("success")
        setMessage(
          `${attendanceMode === "check-in" ? "Check-in" : "Check-out"} saved offline for ${employeeData.name}. It will sync when you're back online.`,
        )
      } else {
        // Send to server
        await logAttendance(attendanceRecord)

        setStatus("success")
        setMessage(`${attendanceMode === "check-in" ? "Check-in" : "Check-out"} successful for ${employeeData.name}`)
      }

      // Add to scan history
      addToScanHistory({
        id: attendanceRecord.id,
        employeeId: employeeData.id,
        employeeName: employeeData.name,
        type: attendanceMode,
        timestamp: new Date().toISOString(),
        success: true,
      })

      // Show confetti and play success sound
      setShowConfetti(true)
      feedback("success")

      // Show browser notification
      showNotification(
        "Attendance Recorded",
        `${employeeData.name} ${attendanceMode === "check-in" ? "checked in" : "checked out"} successfully.`,
      )
    } catch (error) {
      console.error("Error logging attendance:", error)
      setStatus("error")
      setMessage("Failed to log attendance. Please try again.")

      // Add to scan history as failed
      addToScanHistory({
        id: `failed-${Date.now()}`,
        employeeId: employeeData.id,
        employeeName: employeeData.name,
        type: attendanceMode,
        timestamp: new Date().toISOString(),
        success: false,
      })

      // Play error sound
      feedback("error")
    }
  }

  // Save offline record to IndexedDB
  const saveOfflineRecord = async (record: any) => {
    try {
      const db = await openDatabase()
      const transaction = db.transaction(["offlineRecords"], "readwrite")
      const store = transaction.objectStore("offlineRecords")
      await store.add(record)

      // Request background sync if supported
      if ("serviceWorker" in navigator && "SyncManager" in window) {
        const registration = await navigator.serviceWorker.ready
        await registration.sync.register("sync-attendance")
      }
    } catch (error) {
      console.error("Failed to save offline record:", error)
    }
  }

  // Open IndexedDB
  const openDatabase = () => {
    return new Promise<IDBDatabase>((resolve, reject) => {
      const request = indexedDB.open("QRPresenceDB", 1)

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result
        if (!db.objectStoreNames.contains("offlineRecords")) {
          db.createObjectStore("offlineRecords", { keyPath: "id" })
        }
      }

      request.onsuccess = (event) => resolve((event.target as IDBOpenDBRequest).result)
      request.onerror = (event) => reject((event.target as IDBOpenDBRequest).error)
    })
  }

  // Add to scan history
  const addToScanHistory = (scan: any) => {
    const savedHistory = localStorage.getItem("scan-history")
    let history = []

    if (savedHistory) {
      try {
        history = JSON.parse(savedHistory)
      } catch (error) {
        console.error("Failed to parse scan history:", error)
      }
    }

    const updatedHistory = [scan, ...history].slice(0, 50) // Keep last 50 scans
    localStorage.setItem("scan-history", JSON.stringify(updatedHistory))
  }

  // Show browser notification
  const showNotification = (title: string, body: string) => {
    if ("Notification" in window) {
      if (Notification.permission === "granted") {
        new Notification(title, { body, icon: "/icons/icon-192.png" })
      } else if (Notification.permission !== "denied") {
        Notification.requestPermission().then((permission) => {
          if (permission === "granted") {
            new Notification(title, { body, icon: "/icons/icon-192.png" })
          }
        })
      }
    }
  }

  // Reset everything
  const resetVerification = () => {
    setCurrentStep("qr")
    setVerificationProgress(0)
    setStatus(null)
    setMessage("")
    setEmployeeData(null)
    setShowConfetti(false)
  }

  return (
    <div className="max-w-2xl mx-auto">
      {/* Offline indicator */}
      {isOffline && (
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>You are offline</AlertTitle>
          <AlertDescription>
            Attendance records will be saved locally and synced when you're back online.
          </AlertDescription>
        </Alert>
      )}

      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold gradient-heading">Secure Attendance Verification</h1>
        <div className="flex items-center gap-2">
          <ScanHistory className="rounded-full" />
          <SettingsPanel className="rounded-full" />
        </div>
      </div>

      <Card className="mb-6 glass-card">
        <CardHeader>
          <CardTitle>Multi-Factor Attendance Verification</CardTitle>
          <CardDescription>Complete all verification steps to record your attendance</CardDescription>
        </CardHeader>
        <CardContent>
          {/* Progress Steps */}
          <div className="mb-6" id="verification-steps">
            <div className="flex justify-between mb-2 text-sm">
              <motion.div
                className="flex items-center gap-1"
                animate={{
                  opacity: currentStep === "qr" ? 1 : 0.5,
                  scale: currentStep === "qr" ? 1.05 : 1,
                }}
              >
                <QrCode className={`h-4 w-4 ${currentStep === "qr" ? "text-primary" : "text-muted-foreground"}`} />
                <span className={currentStep === "qr" ? "font-medium text-primary" : "text-muted-foreground"}>
                  QR Scan
                </span>
              </motion.div>
              <motion.div
                className="flex items-center gap-1"
                animate={{
                  opacity: currentStep === "face" ? 1 : 0.5,
                  scale: currentStep === "face" ? 1.05 : 1,
                }}
              >
                <User className={`h-4 w-4 ${currentStep === "face" ? "text-primary" : "text-muted-foreground"}`} />
                <span className={currentStep === "face" ? "font-medium text-primary" : "text-muted-foreground"}>
                  Face Verification
                </span>
              </motion.div>
              <motion.div
                className="flex items-center gap-1"
                animate={{
                  opacity: currentStep === "location" ? 1 : 0.5,
                  scale: currentStep === "location" ? 1.05 : 1,
                }}
              >
                <MapPin
                  className={`h-4 w-4 ${currentStep === "location" ? "text-primary" : "text-muted-foreground"}`}
                />
                <span className={currentStep === "location" ? "font-medium text-primary" : "text-muted-foreground"}>
                  Location Check
                </span>
              </motion.div>
              <motion.div
                className="flex items-center gap-1"
                animate={{
                  opacity: currentStep === "complete" ? 1 : 0.5,
                  scale: currentStep === "complete" ? 1.05 : 1,
                }}
              >
                <CheckCircle
                  className={`h-4 w-4 ${currentStep === "complete" ? "text-primary" : "text-muted-foreground"}`}
                />
                <span className={currentStep === "complete" ? "font-medium text-primary" : "text-muted-foreground"}>
                  Complete
                </span>
              </motion.div>
            </div>
            <motion.div className="h-2 bg-secondary rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-primary"
                initial={{ width: 0 }}
                animate={{ width: `${verificationProgress}%` }}
                transition={{ duration: 0.5 }}
              />
            </motion.div>
          </div>

          {/* Mode Selection */}
          <div className="flex gap-4 mb-4" id="mode-selection">
            <Button
              variant={attendanceMode === "check-in" ? "default" : "outline"}
              onClick={() => setAttendanceMode("check-in")}
              disabled={currentStep !== "qr"}
              className={`flex-1 rounded-full ${attendanceMode === "check-in" ? "animated-gradient-btn" : ""}`}
            >
              Check-In
            </Button>
            <Button
              variant={attendanceMode === "check-out" ? "default" : "outline"}
              onClick={() => setAttendanceMode("check-out")}
              disabled={currentStep !== "qr"}
              className={`flex-1 rounded-full ${attendanceMode === "check-out" ? "animated-gradient-btn" : ""}`}
            >
              Check-Out
            </Button>
          </div>

          {/* Verification Steps */}
          <Tabs value={currentStep} className="w-full">
            <TabsContent value="qr" className="m-0">
              <div id="qr-scanner">
                <QRScanner onScan={handleQRScan} />
              </div>
            </TabsContent>

            <TabsContent value="face" className="m-0">
              <FaceVerifier onVerified={handleFaceVerified} />
            </TabsContent>

            <TabsContent value="location" className="m-0">
              <LocationVerifier onVerified={handleLocationVerified} />
            </TabsContent>

            <TabsContent value="complete" className="m-0">
              <AnimatePresence>
                {status === "success" && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                  >
                    <Alert className="bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-900">
                      <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
                      <AlertTitle>Success</AlertTitle>
                      <AlertDescription>{message}</AlertDescription>
                    </Alert>

                    <Button onClick={resetVerification} className="w-full mt-4 rounded-full animated-gradient-btn">
                      Scan Another
                    </Button>
                  </motion.div>
                )}

                {status === "error" && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                  >
                    <Alert variant="destructive">
                      <AlertCircle className="h-4 w-4" />
                      <AlertTitle>Error</AlertTitle>
                      <AlertDescription>{message}</AlertDescription>
                    </Alert>

                    <Button onClick={resetVerification} className="w-full mt-4 rounded-full">
                      Try Again
                    </Button>
                  </motion.div>
                )}
              </AnimatePresence>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {employeeData && currentStep === "complete" && (
        <Card className="glass-card">
          <CardHeader>
            <CardTitle>Attendance Record Details</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="grid grid-cols-2 gap-2">
                <div className="text-sm font-medium">Employee ID:</div>
                <div>{employeeData.id}</div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="text-sm font-medium">Name:</div>
                <div>{employeeData.name}</div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="text-sm font-medium">Department:</div>
                <div className="capitalize">{employeeData.department}</div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="text-sm font-medium">Action:</div>
                <div className="capitalize">{attendanceMode}</div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="text-sm font-medium">Time:</div>
                <div>{new Date().toLocaleTimeString()}</div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="text-sm font-medium">Date:</div>
                <div>{new Date().toLocaleDateString()}</div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="text-sm font-medium">Verification:</div>
                <div className="flex items-center">
                  <span className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full dark:bg-green-900/30 dark:text-green-300">
                    Multi-factor
                  </span>
                </div>
              </div>
              {isOffline && (
                <div className="grid grid-cols-2 gap-2">
                  <div className="text-sm font-medium">Status:</div>
                  <div className="flex items-center">
                    <span className="bg-amber-100 text-amber-800 text-xs px-2 py-1 rounded-full dark:bg-amber-900/30 dark:text-amber-300">
                      Saved offline (will sync later)
                    </span>
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* First-time user tour */}
      <FeatureTour
        steps={tourSteps}
        isOpen={showTour}
        onOpenChange={setShowTour}
        onComplete={() => setShowTour(false)}
      />

      {/* Confetti celebration */}
      <ConfettiCelebration trigger={showConfetti} />

      {/* Help button for new users */}
      {isFirstVisit && (
        <Button
          variant="outline"
          size="icon"
          className="fixed bottom-4 right-4 rounded-full h-12 w-12 shadow-lg bg-white dark:bg-gray-800"
          onClick={() => setShowTour(true)}
        >
          <Info className="h-6 w-6" />
        </Button>
      )}
    </div>
  )
}

