// Theme configuration for the application
export const themeConfig = {
  // Light mode colors
  light: {
    primary: "250 47% 45%",
    primaryForeground: "210 20% 98%",
    secondary: "250 30% 96%",
    secondaryForeground: "250 47% 35%",
    accent: "174 75% 37%",
    background: "210 20% 98%",
    foreground: "215 25% 27%",
    muted: "210 20% 96%",
    mutedForeground: "215 25% 40%",
    card: "0 0% 100%",
    cardForeground: "215 25% 27%",
    border: "214.3 31.8% 91.4%",
    input: "214.3 31.8% 91.4%",
  },
  // Dark mode colors
  dark: {
    primary: "250 47% 65%",
    primaryForeground: "215 28% 17%",
    secondary: "215 25% 27%",
    secondaryForeground: "210 20% 98%",
    accent: "174 75% 37%",
    background: "215 28% 17%",
    foreground: "210 20% 98%",
    muted: "215 25% 27%",
    mutedForeground: "210 40% 80%",
    card: "215 28% 17%",
    cardForeground: "210 20% 98%",
    border: "215 25% 27%",
    input: "215 25% 27%",
  },
}

