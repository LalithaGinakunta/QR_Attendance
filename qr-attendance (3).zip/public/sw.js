// Service Worker for QR Presence

const CACHE_NAME = "qr-presence-v1"

// Assets to cache on install
const PRECACHE_ASSETS = [
  "/",
  "/index.html",
  "/manifest.json",
  "/icons/icon-192.png",
  "/icons/icon-512.png",
  "/sounds/success.mp3",
  "/sounds/error.mp3",
  "/sounds/scan.mp3",
  "/sounds/notification.mp3",
]

// Install event - precache assets
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(CACHE_NAME)
      .then((cache) => cache.addAll(PRECACHE_ASSETS))
      .then(() => self.skipWaiting()),
  )
})

// Activate event - clean up old caches
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((cacheNames) => {
        return Promise.all(
          cacheNames
            .filter((cacheName) => {
              return cacheName !== CACHE_NAME
            })
            .map((cacheName) => {
              return caches.delete(cacheName)
            }),
        )
      })
      .then(() => self.clients.claim()),
  )
})

// Fetch event - serve from cache or network
self.addEventListener("fetch", (event) => {
  // Skip cross-origin requests
  if (!event.request.url.startsWith(self.location.origin)) {
    return
  }

  // Network-first strategy for API requests
  if (event.request.url.includes("/api/")) {
    event.respondWith(
      fetch(event.request)
        .then((response) => {
          // Clone the response to store in cache
          const responseToCache = response.clone()
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseToCache)
          })
          return response
        })
        .catch(() => {
          // Fallback to cache if network fails
          return caches.match(event.request)
        }),
    )
    return
  }

  // Cache-first strategy for static assets
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      if (cachedResponse) {
        return cachedResponse
      }

      return fetch(event.request).then((response) => {
        // Don't cache non-successful responses
        if (!response || response.status !== 200 || response.type !== "basic") {
          return response
        }

        // Clone the response to store in cache
        const responseToCache = response.clone()
        caches.open(CACHE_NAME).then((cache) => {
          cache.put(event.request, responseToCache)
        })

        return response
      })
    }),
  )
})

// Background sync for offline attendance records
self.addEventListener("sync", (event) => {
  if (event.tag === "sync-attendance") {
    event.waitUntil(syncAttendanceRecords())
  }
})

// Push notification handler
self.addEventListener("push", (event) => {
  const data = event.data.json()

  const options = {
    body: data.body,
    icon: "/icons/icon-192.png",
    badge: "/icons/badge.png",
    vibrate: [100, 50, 100],
    data: {
      url: data.url || "/",
    },
  }

  event.waitUntil(self.registration.showNotification(data.title, options))
})

// Notification click handler
self.addEventListener("notificationclick", (event) => {
  event.notification.close()

  event.waitUntil(clients.openWindow(event.notification.data.url))
})

// Function to sync offline attendance records
async function syncAttendanceRecords() {
  try {
    // Get offline records from IndexedDB
    const db = await openDatabase()
    const offlineRecords = await getOfflineRecords(db)

    // If no offline records, return
    if (!offlineRecords.length) return

    // Try to sync each record
    const syncPromises = offlineRecords.map(async (record) => {
      try {
        const response = await fetch("/api/attendance", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(record),
        })

        if (response.ok) {
          // If successful, remove from offline storage
          await deleteOfflineRecord(db, record.id)
        }
      } catch (error) {
        console.error("Failed to sync record:", error)
      }
    })

    await Promise.all(syncPromises)
  } catch (error) {
    console.error("Sync failed:", error)
  }
}

// IndexedDB helper functions
function openDatabase() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open("QRPresenceDB", 1)

    request.onupgradeneeded = (event) => {
      const db = event.target.result
      if (!db.objectStoreNames.contains("offlineRecords")) {
        db.createObjectStore("offlineRecords", { keyPath: "id" })
      }
    }

    request.onsuccess = (event) => resolve(event.target.result)
    request.onerror = (event) => reject(event.target.error)
  })
}

function getOfflineRecords(db) {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(["offlineRecords"], "readonly")
    const store = transaction.objectStore("offlineRecords")
    const request = store.getAll()

    request.onsuccess = (event) => resolve(event.target.result)
    request.onerror = (event) => reject(event.target.error)
  })
}

function deleteOfflineRecord(db, id) {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(["offlineRecords"], "readwrite")
    const store = transaction.objectStore("offlineRecords")
    const request = store.delete(id)

    request.onsuccess = (event) => resolve()
    request.onerror = (event) => reject(event.target.error)
  })
}

