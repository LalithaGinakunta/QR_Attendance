"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import { History, Trash2, CheckCircle, XCircle } from "lucide-react"
import { format } from "date-fns"

interface ScanRecord {
  id: string
  employeeId: string
  employeeName: string
  type: "check-in" | "check-out"
  timestamp: string
  success: boolean
}

interface ScanHistoryProps {
  className?: string
}

export function ScanHistory({ className }: ScanHistoryProps) {
  const [history, setHistory] = useState<ScanRecord[]>([])

  // Load history from local storage
  useEffect(() => {
    const savedHistory = localStorage.getItem("scan-history")
    if (savedHistory) {
      try {
        setHistory(JSON.parse(savedHistory))
      } catch (error) {
        console.error("Failed to parse scan history:", error)
      }
    }
  }, [])

  // Add a new scan to history
  const addScan = (scan: ScanRecord) => {
    const updatedHistory = [scan, ...history].slice(0, 50) // Keep last 50 scans
    setHistory(updatedHistory)
    localStorage.setItem("scan-history", JSON.stringify(updatedHistory))
  }

  // Clear history
  const clearHistory = () => {
    setHistory([])
    localStorage.removeItem("scan-history")
  }

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className={className}>
          <History className="h-5 w-5" />
          <span className="sr-only">Scan History</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>Recent Scans</span>
            {history.length > 0 && (
              <Button variant="ghost" size="sm" onClick={clearHistory} className="h-8 gap-1 text-xs">
                <Trash2 className="h-3.5 w-3.5" />
                Clear
              </Button>
            )}
          </DialogTitle>
        </DialogHeader>

        <ScrollArea className="h-[400px] pr-4">
          {history.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center p-4">
              <History className="h-12 w-12 text-muted-foreground mb-2 opacity-50" />
              <p className="text-muted-foreground">No scan history yet</p>
              <p className="text-xs text-muted-foreground mt-1">Your recent scans will appear here</p>
            </div>
          ) : (
            <div className="space-y-3">
              {history.map((scan) => (
                <div key={scan.id} className="flex items-start gap-3 p-3 rounded-lg border bg-card">
                  <div className={`mt-0.5 ${scan.success ? "text-green-500" : "text-red-500"}`}>
                    {scan.success ? <CheckCircle className="h-5 w-5" /> : <XCircle className="h-5 w-5" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className="font-medium truncate">{scan.employeeName}</p>
                      <span className="text-xs text-muted-foreground">
                        {format(new Date(scan.timestamp), "MMM d, h:mm a")}
                      </span>
                    </div>
                    <div className="flex items-center justify-between mt-1">
                      <p className="text-sm text-muted-foreground">
                        {scan.employeeId} • {scan.type === "check-in" ? "Checked In" : "Checked Out"}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  )
}

