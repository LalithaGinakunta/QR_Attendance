"use client"

import { useEffect, useState } from "react"
import confetti from "canvas-confetti"

interface ConfettiCelebrationProps {
  trigger?: boolean
  duration?: number
}

export function ConfettiCelebration({ trigger = false, duration = 3000 }: ConfettiCelebrationProps) {
  const [isActive, setIsActive] = useState(false)

  useEffect(() => {
    if (trigger && !isActive) {
      setIsActive(true)

      // Create confetti burst
      const end = Date.now() + duration

      // Realistic confetti with gravity
      const colors = ["#4f46e5", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6"]

      // Initial burst
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors,
        disableForReducedMotion: true,
      })

      // Continuous confetti for the duration
      const interval = setInterval(() => {
        if (Date.now() > end) {
          clearInterval(interval)
          setIsActive(false)
          return
        }

        // Random confetti bursts
        confetti({
          particleCount: 20,
          angle: Math.random() * 360,
          spread: 30,
          origin: {
            x: Math.random(),
            y: Math.random() - 0.2,
          },
          colors,
          disableForReducedMotion: true,
        })
      }, 250)

      return () => clearInterval(interval)
    }
  }, [trigger, duration])

  return null
}

