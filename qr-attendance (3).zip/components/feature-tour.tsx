"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { X } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

interface TourStep {
  target: string
  title: string
  content: string
  position: "top" | "right" | "bottom" | "left"
}

interface FeatureTourProps {
  steps: TourStep[]
  onComplete?: () => void
  isOpen?: boolean
  onOpenChange?: (open: boolean) => void
}

export function FeatureTour({ steps, onComplete, isOpen = false, onOpenChange }: FeatureTourProps) {
  const [currentStep, setCurrentStep] = useState(0)
  const [isVisible, setIsVisible] = useState(isOpen)
  const [hasSeenTour, setHasSeenTour] = useState(false)

  // Check if user has seen the tour before
  useEffect(() => {
    const tourSeen = localStorage.getItem("feature-tour-seen")
    if (tourSeen) {
      setHasSeenTour(true)
    }
  }, [])

  // Handle external open state changes
  useEffect(() => {
    setIsVisible(isOpen)
  }, [isOpen])

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep((prev) => prev + 1)
    } else {
      handleComplete()
    }
  }

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep((prev) => prev - 1)
    }
  }

  const handleComplete = () => {
    setIsVisible(false)
    localStorage.setItem("feature-tour-seen", "true")
    setHasSeenTour(true)
    onComplete?.()
    onOpenChange?.(false)
  }

  // Skip the tour if user has seen it before
  if (hasSeenTour && !isOpen) {
    return null
  }

  return (
    <AnimatePresence>
      {isVisible && steps[currentStep] && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/50"
        >
          <div className="absolute inset-0" onClick={handleComplete} />

          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            transition={{ type: "spring", damping: 20 }}
            className="relative z-10"
          >
            <Card className="w-80 p-4 shadow-xl">
              <Button variant="ghost" size="icon" className="absolute right-2 top-2" onClick={handleComplete}>
                <X className="h-4 w-4" />
              </Button>

              <div className="mb-4">
                <h3 className="text-lg font-semibold">{steps[currentStep].title}</h3>
                <p className="text-sm text-muted-foreground mt-1">{steps[currentStep].content}</p>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex space-x-1">
                  {steps.map((_, index) => (
                    <div
                      key={index}
                      className={`h-1.5 w-6 rounded-full ${index === currentStep ? "bg-primary" : "bg-muted"}`}
                    />
                  ))}
                </div>

                <div className="flex space-x-2">
                  {currentStep > 0 && (
                    <Button variant="outline" size="sm" onClick={handlePrevious}>
                      Previous
                    </Button>
                  )}

                  <Button size="sm" onClick={handleNext} className="animated-gradient-btn">
                    {currentStep < steps.length - 1 ? "Next" : "Finish"}
                  </Button>
                </div>
              </div>
            </Card>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

