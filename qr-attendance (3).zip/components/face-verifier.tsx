"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { CameraOff, RefreshCw, CheckCircle } from "lucide-react"

interface FaceVerifierProps {
  onVerified: () => void
  onError?: (error: Error) => void
}

export function FaceVerifier({ onVerified, onError }: FaceVerifierProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [active, setActive] = useState(false)
  const [cameraError, setCameraError] = useState<string | null>(null)
  const [verificationStatus, setVerificationStatus] = useState<"idle" | "scanning" | "success" | "error">("idle")
  const streamRef = useRef<MediaStream | null>(null)
  const detectionTimeoutRef = useRef<NodeJS.Timeout | null>(null)

  // Start face verification
  const startVerification = async () => {
    try {
      setCameraError(null)
      setActive(true)
      setVerificationStatus("scanning")

      // Stop any existing stream
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop())
      }

      // Request camera access with front camera
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: "user",
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
      })

      streamRef.current = stream

      // Set video source
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        await videoRef.current.play()

        // Simulate face detection (in a real app, use a face detection library)
        simulateFaceDetection()
      }
    } catch (error: any) {
      console.error("Camera access error:", error)
      setActive(false)
      setVerificationStatus("error")

      // Provide user-friendly error messages
      if (error.name === "NotAllowedError") {
        setCameraError("Camera access denied. Please allow camera access and try again.")
      } else if (error.name === "NotFoundError") {
        setCameraError("No camera found. Please ensure your device has a working camera.")
      } else if (error.name === "NotReadableError") {
        setCameraError("Camera is in use by another application. Please close other apps using the camera.")
      } else {
        setCameraError(`Camera error: ${error.message || "Unknown error"}`)
      }

      onError?.(error)
    }
  }

  // Stop face verification
  const stopVerification = () => {
    setActive(false)

    // Clear detection timeout
    if (detectionTimeoutRef.current) {
      clearTimeout(detectionTimeoutRef.current)
      detectionTimeoutRef.current = null
    }

    // Stop camera stream
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
    }

    // Clear video source
    if (videoRef.current) {
      videoRef.current.srcObject = null
    }
  }

  // Simulate face detection (replace with actual face detection in production)
  const simulateFaceDetection = () => {
    // Clear any existing timeout
    if (detectionTimeoutRef.current) {
      clearTimeout(detectionTimeoutRef.current)
    }

    // Simulate processing time (2-4 seconds)
    const detectionTime = 2000 + Math.random() * 2000

    detectionTimeoutRef.current = setTimeout(() => {
      // Simulate 90% success rate
      const success = Math.random() < 0.9

      if (success) {
        setVerificationStatus("success")

        // Draw face detection box on canvas
        if (canvasRef.current && videoRef.current) {
          const canvas = canvasRef.current
          const context = canvas.getContext("2d")

          if (context) {
            canvas.width = videoRef.current.videoWidth
            canvas.height = videoRef.current.videoHeight

            // Draw video frame
            context.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height)

            // Draw face detection box (simulated)
            const centerX = canvas.width / 2
            const centerY = canvas.height / 2
            const boxWidth = canvas.width / 3
            const boxHeight = canvas.height / 2

            context.beginPath()
            context.rect(centerX - boxWidth / 2, centerY - boxHeight / 2, boxWidth, boxHeight)
            context.lineWidth = 4
            context.strokeStyle = "#10b981" // Success color
            context.stroke()
          }
        }

        // Notify parent component after a brief delay to show success state
        setTimeout(() => {
          onVerified()
        }, 1500)
      } else {
        setVerificationStatus("error")
      }
    }, detectionTime)
  }

  // Auto-start verification on mount
  useEffect(() => {
    startVerification()

    // Cleanup on unmount
    return () => {
      stopVerification()
    }
  }, [])

  return (
    <div className="relative w-full">
      {/* Video element for camera feed */}
      <div className="relative aspect-video bg-muted rounded-lg overflow-hidden">
        <video ref={videoRef} className="absolute inset-0 w-full h-full object-cover" playsInline muted />

        {/* Canvas overlay for face detection visualization */}
        <canvas
          ref={canvasRef}
          className={`absolute inset-0 w-full h-full ${verificationStatus === "success" ? "opacity-100" : "opacity-0"}`}
        />

        {/* Face detection status indicator */}
        {verificationStatus !== "idle" && (
          <div className={`face-detection-status ${verificationStatus}`}>
            {verificationStatus === "scanning" && "Scanning..."}
            {verificationStatus === "success" && "Face Verified"}
            {verificationStatus === "error" && "Verification Failed"}
          </div>
        )}

        {/* Error state */}
        {cameraError && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-muted/90 p-4">
            <CameraOff className="h-12 w-12 text-destructive mb-2" />
            <p className="text-center text-destructive font-medium mb-2">Camera Error</p>
            <p className="text-center text-sm text-muted-foreground mb-4">{cameraError}</p>
            <Button
              onClick={startVerification}
              variant="default"
              size="sm"
              className="rounded-full animated-gradient-btn"
            >
              <RefreshCw className="mr-2 h-4 w-4" />
              Retry Camera
            </Button>
          </div>
        )}

        {/* Loading state */}
        {active && !cameraError && !streamRef.current && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-muted/90">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mb-4"></div>
            <p className="text-muted-foreground">Accessing camera...</p>
            <p className="text-xs text-muted-foreground mt-1">Please look directly at the camera</p>
          </div>
        )}

        {/* Success overlay */}
        {verificationStatus === "success" && (
          <div className="absolute inset-0 bg-green-500/10 flex items-center justify-center">
            <div className="bg-white rounded-full p-3 shadow-lg">
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
          </div>
        )}
      </div>

      {/* Instructions */}
      <div className="mt-4 text-center">
        <p className="text-sm text-muted-foreground">
          {verificationStatus === "scanning" && "Please look directly at the camera and keep your face centered"}
          {verificationStatus === "success" && "Face verification successful!"}
          {verificationStatus === "error" && "Face verification failed. Please try again."}
        </p>

        {/* Retry button for error state */}
        {verificationStatus === "error" && (
          <Button onClick={startVerification} className="mt-2 rounded-full animated-gradient-btn">
            <RefreshCw className="mr-2 h-4 w-4" />
            Retry Verification
          </Button>
        )}
      </div>
    </div>
  )
}

