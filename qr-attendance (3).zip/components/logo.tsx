import Image from "next/image"
import Link from "next/link"

export function Logo() {
  return (
    <Link href="/" className="flex items-center gap-2 hover:opacity-90 transition-opacity">
      <div className="relative w-10 h-10">
        <Image
          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Beige%20and%20Black%20Minimalist%20Qr%20Code%20Business%20Square%20Sticker-gJd07Mr8UTIOqY9NJZGOJNWuN7buAi.png"
          alt="QR Presence Logo"
          fill
          className="object-contain"
          priority
        />
      </div>
      <span className="text-lg font-bold gradient-heading">QR Presence</span>
    </Link>
  )
}

