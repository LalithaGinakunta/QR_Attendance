"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Settings, Volume2, Moon, Sun } from "lucide-react"
import { useTheme } from "next-themes"

interface SettingsPanelProps {
  className?: string
}

export function SettingsPanel({ className }: SettingsPanelProps) {
  const { theme, setTheme } = useTheme()
  const [soundEnabled, setSoundEnabled] = useState(true)
  const [vibrationEnabled, setVibrationEnabled] = useState(true)
  const [notificationsEnabled, setNotificationsEnabled] = useState(false)
  const [soundVolume, setSoundVolume] = useState(80)
  const [highPerformanceMode, setHighPerformanceMode] = useState(false)
  const [autoScanEnabled, setAutoScanEnabled] = useState(true)

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className={className}>
          <Settings className="h-5 w-5" />
          <span className="sr-only">Settings</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Settings</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="general" className="mt-4">
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="general">General</TabsTrigger>
            <TabsTrigger value="audio">Audio & Haptics</TabsTrigger>
            <TabsTrigger value="advanced">Advanced</TabsTrigger>
          </TabsList>

          <TabsContent value="general" className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="theme-toggle">Theme</Label>
                <div className="text-sm text-muted-foreground">Choose between light and dark mode</div>
              </div>
              <div className="flex items-center space-x-2">
                <Sun className="h-4 w-4 text-muted-foreground" />
                <Switch
                  id="theme-toggle"
                  checked={theme === "dark"}
                  onCheckedChange={(checked) => setTheme(checked ? "dark" : "light")}
                />
                <Moon className="h-4 w-4 text-muted-foreground" />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="notifications">Notifications</Label>
                <div className="text-sm text-muted-foreground">Enable browser notifications</div>
              </div>
              <Switch id="notifications" checked={notificationsEnabled} onCheckedChange={setNotificationsEnabled} />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="auto-scan">Auto-start Scanning</Label>
                <div className="text-sm text-muted-foreground">Automatically start camera when page loads</div>
              </div>
              <Switch id="auto-scan" checked={autoScanEnabled} onCheckedChange={setAutoScanEnabled} />
            </div>
          </TabsContent>

          <TabsContent value="audio" className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="sound-toggle">Sound Effects</Label>
                <div className="text-sm text-muted-foreground">Play sounds for actions and notifications</div>
              </div>
              <Switch id="sound-toggle" checked={soundEnabled} onCheckedChange={setSoundEnabled} />
            </div>

            {soundEnabled && (
              <div className="space-y-2">
                <div className="flex justify-between">
                  <Label htmlFor="volume-slider">Volume</Label>
                  <span className="text-sm text-muted-foreground">{soundVolume}%</span>
                </div>
                <div className="flex items-center gap-2">
                  <Volume2 className="h-4 w-4 text-muted-foreground" />
                  <Slider
                    id="volume-slider"
                    min={0}
                    max={100}
                    step={1}
                    value={[soundVolume]}
                    onValueChange={(value) => setSoundVolume(value[0])}
                  />
                </div>
              </div>
            )}

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="vibration-toggle">Vibration</Label>
                <div className="text-sm text-muted-foreground">Vibrate on actions (mobile devices)</div>
              </div>
              <Switch id="vibration-toggle" checked={vibrationEnabled} onCheckedChange={setVibrationEnabled} />
            </div>
          </TabsContent>

          <TabsContent value="advanced" className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="performance-mode">High Performance Mode</Label>
                <div className="text-sm text-muted-foreground">Improves scanning speed but uses more battery</div>
              </div>
              <Switch id="performance-mode" checked={highPerformanceMode} onCheckedChange={setHighPerformanceMode} />
            </div>

            <div className="pt-4 border-t">
              <Button
                variant="outline"
                className="w-full"
                onClick={() => {
                  localStorage.removeItem("feature-tour-seen")
                  localStorage.removeItem("scan-history")
                  window.location.reload()
                }}
              >
                Reset All Settings
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}

