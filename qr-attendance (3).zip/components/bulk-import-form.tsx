"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { FileSpreadsheet, Upload, X, FileCheck, AlertCircle } from "lucide-react"
import * as XLSX from "xlsx"

interface BulkImportFormProps {
  onImport: (employees: any[]) => void
}

export function BulkImportForm({ onImport }: BulkImportFormProps) {
  const [file, setFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<any[]>([])
  const [error, setError] = useState<string>("")

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    // Reset states
    setError("")
    setPreview([])

    // Validate file type
    const validTypes = [
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "application/vnd.ms-excel",
      "text/csv",
    ]
    if (!validTypes.includes(file.type)) {
      setError("Please upload a valid Excel or CSV file")
      return
    }

    try {
      const data = await readFileData(file)
      if (validateData(data)) {
        setFile(file)
        setPreview(data.slice(0, 5)) // Show first 5 rows as preview
      }
    } catch (err) {
      setError("Error reading file. Please check the format.")
    }
  }

  const readFileData = (file: File): Promise<any[]> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()

      reader.onload = (e) => {
        try {
          const data = e.target?.result
          const workbook = XLSX.read(data, { type: "binary" })
          const sheetName = workbook.SheetNames[0]
          const sheet = workbook.Sheets[sheetName]
          const jsonData = XLSX.utils.sheet_to_json(sheet)

          // Transform data to match expected format
          const formattedData = jsonData.map((row: any) => ({
            name: row.Name || row.name || "",
            id: row.ID || row.id || "",
            department: row.Department || row.department || "",
            email: row.Email || row.email || "",
            position: row.Position || row.position || "",
          }))

          resolve(formattedData)
        } catch (err) {
          reject(err)
        }
      }

      reader.onerror = (err) => reject(err)
      reader.readAsBinaryString(file)
    })
  }

  const validateData = (data: any[]): boolean => {
    if (data.length === 0) {
      setError("File is empty")
      return false
    }

    const requiredFields = ["name", "id", "department"]
    const isValid = data.every((row) =>
      requiredFields.every((field) => row[field] && row[field].toString().trim() !== ""),
    )

    if (!isValid) {
      setError("Some rows are missing required fields (Name, ID, Department)")
      return false
    }

    return true
  }

  const handleImport = async () => {
    if (!file) return

    try {
      const data = await readFileData(file)
      if (validateData(data)) {
        onImport(data)
        setFile(null)
        setPreview([])
      }
    } catch (err) {
      setError("Error processing file")
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col items-center justify-center border-2 border-dashed border-primary/20 rounded-lg p-8 transition-colors hover:border-primary/40">
        <Input type="file" accept=".xlsx,.xls,.csv" onChange={handleFileChange} className="hidden" id="file-upload" />
        <Label htmlFor="file-upload" className="flex flex-col items-center gap-2 cursor-pointer">
          <div className="p-4 rounded-full bg-primary/10">
            <Upload className="h-6 w-6 text-primary" />
          </div>
          <span className="text-sm font-medium">Upload Excel or CSV file</span>
          <span className="text-xs text-muted-foreground">Drag and drop or click to browse</span>
        </Label>
      </div>

      {error && (
        <div className="flex items-center gap-2 text-sm text-destructive bg-destructive/10 rounded-lg p-3">
          <AlertCircle className="h-4 w-4" />
          {error}
        </div>
      )}

      {preview.length > 0 && (
        <Card className="p-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <FileCheck className="h-5 w-5 text-primary" />
              <span className="font-medium">File Preview</span>
            </div>
            <div className="text-sm text-muted-foreground">
              Showing {preview.length} of {file?.name}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-2 px-3 font-medium">Name</th>
                  <th className="text-left py-2 px-3 font-medium">ID</th>
                  <th className="text-left py-2 px-3 font-medium">Department</th>
                  <th className="text-left py-2 px-3 font-medium">Email</th>
                  <th className="text-left py-2 px-3 font-medium">Position</th>
                </tr>
              </thead>
              <tbody>
                {preview.map((row, index) => (
                  <tr key={index} className="border-b last:border-0">
                    <td className="py-2 px-3">{row.name}</td>
                    <td className="py-2 px-3">{row.id}</td>
                    <td className="py-2 px-3 capitalize">{row.department}</td>
                    <td className="py-2 px-3">{row.email}</td>
                    <td className="py-2 px-3">{row.position}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex justify-end gap-2 mt-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setFile(null)
                setPreview([])
              }}
              className="rounded-full"
            >
              <X className="h-4 w-4 mr-2" />
              Cancel
            </Button>
            <Button size="sm" onClick={handleImport} className="rounded-full animated-gradient-btn">
              <FileSpreadsheet className="h-4 w-4 mr-2" />
              Import{" "}
              {file
                ? XLSX.utils.sheet_to_json(
                    XLSX.read(await file.arrayBuffer(), { type: "array" }).Sheets[
                      XLSX.read(await file.arrayBuffer(), { type: "array" }).SheetNames[0]
                    ],
                  ).length
                : 0}{" "}
              Employees
            </Button>
          </div>
        </Card>
      )}

      <div className="bg-secondary/50 p-4 rounded-lg">
        <h3 className="text-sm font-medium mb-2">Template Format</h3>
        <p className="text-sm text-muted-foreground mb-2">Your Excel or CSV file should have the following columns:</p>
        <div className="bg-background p-3 rounded-lg">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b">
                <th className="text-left py-1 px-2 font-medium">Column</th>
                <th className="text-left py-1 px-2 font-medium">Required</th>
                <th className="text-left py-1 px-2 font-medium">Example</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b">
                <td className="py-1 px-2">Name</td>
                <td className="py-1 px-2 text-green-600">Yes</td>
                <td className="py-1 px-2">John Doe</td>
              </tr>
              <tr className="border-b">
                <td className="py-1 px-2">ID</td>
                <td className="py-1 px-2 text-green-600">Yes</td>
                <td className="py-1 px-2">EMP001</td>
              </tr>
              <tr className="border-b">
                <td className="py-1 px-2">Department</td>
                <td className="py-1 px-2 text-green-600">Yes</td>
                <td className="py-1 px-2">Engineering</td>
              </tr>
              <tr className="border-b">
                <td className="py-1 px-2">Email</td>
                <td className="py-1 px-2 text-muted-foreground">No</td>
                <td className="py-1 px-2">john@example.com</td>
              </tr>
              <tr>
                <td className="py-1 px-2">Position</td>
                <td className="py-1 px-2 text-muted-foreground">No</td>
                <td className="py-1 px-2">Software Engineer</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

