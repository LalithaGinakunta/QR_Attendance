"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { MapPin, AlertCircle, RefreshCw, CheckCircle } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

interface LocationVerifierProps {
  onVerified: () => void
  onError?: (error: Error) => void
  // Office coordinates (default to San Francisco)
  officeLocation?: {
    latitude: number
    longitude: number
    radius: number // in meters
    name: string
  }
}

export function LocationVerifier({
  onVerified,
  onError,
  officeLocation = {
    latitude: 37.7749,
    longitude: -122.4194,
    radius: 100,
    name: "Main Office",
  },
}: LocationVerifierProps) {
  const [location, setLocation] = useState<GeolocationPosition | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [distance, setDistance] = useState<number | null>(null)
  const [status, setStatus] = useState<"idle" | "checking" | "success" | "error">("idle")

  // Start location verification
  const checkLocation = () => {
    setStatus("checking")
    setError(null)

    if (!navigator.geolocation) {
      setError("Geolocation is not supported by your browser")
      setStatus("error")
      onError?.(new Error("Geolocation not supported"))
      return
    }

    navigator.geolocation.getCurrentPosition(
      // Success handler
      (position) => {
        setLocation(position)

        // Calculate distance from office
        const calculatedDistance = calculateDistance(
          position.coords.latitude,
          position.coords.longitude,
          officeLocation.latitude,
          officeLocation.longitude,
        )

        setDistance(calculatedDistance)

        // Check if within allowed radius
        if (calculatedDistance <= officeLocation.radius) {
          setStatus("success")

          // Notify parent after a brief delay to show success state
          setTimeout(() => {
            onVerified()
          }, 1500)
        } else {
          setStatus("error")
          setError(`You are ${Math.round(calculatedDistance)} meters away from ${officeLocation.name}. 
                   You need to be within ${officeLocation.radius} meters.`)
        }
      },
      // Error handler
      (error) => {
        console.error("Geolocation error:", error)
        setStatus("error")

        // Provide user-friendly error messages
        switch (error.code) {
          case error.PERMISSION_DENIED:
            setError("Location access denied. Please enable location services and try again.")
            break
          case error.POSITION_UNAVAILABLE:
            setError("Location information is unavailable. Please try again later.")
            break
          case error.TIMEOUT:
            setError("Location request timed out. Please try again.")
            break
          default:
            setError(`Location error: ${error.message || "Unknown error"}`)
        }

        onError?.(error)
      },
      // Options
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      },
    )
  }

  // Calculate distance between two coordinates in meters (Haversine formula)
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371e3 // Earth radius in meters
    const φ1 = (lat1 * Math.PI) / 180
    const φ2 = (lat2 * Math.PI) / 180
    const Δφ = ((lat2 - lat1) * Math.PI) / 180
    const Δλ = ((lon2 - lon1) * Math.PI) / 180

    const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) + Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))

    return R * c // Distance in meters
  }

  // Auto-start location check on mount
  useEffect(() => {
    checkLocation()
  }, [])

  return (
    <div className="w-full">
      <div className="bg-muted rounded-lg p-6">
        <div className="text-center mb-6">
          <div className="inline-flex p-3 rounded-full bg-primary/10 mb-3">
            <MapPin className="h-8 w-8 text-primary" />
          </div>
          <h3 className="text-lg font-medium">Location Verification</h3>
          <p className="text-sm text-muted-foreground">Verifying you are at {officeLocation.name}</p>
        </div>

        {/* Checking state */}
        {status === "checking" && (
          <div className="flex items-center justify-center p-6">
            <div className="location-pulse">
              <span className="absolute inline-flex rounded-full h-3 w-3 bg-accent"></span>
            </div>
            <span className="ml-4">Checking your location...</span>
          </div>
        )}

        {/* Location data */}
        {location && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div className="font-medium">Latitude:</div>
              <div>{location.coords.latitude.toFixed(6)}</div>
              <div className="font-medium">Longitude:</div>
              <div>{location.coords.longitude.toFixed(6)}</div>
              {distance !== null && (
                <>
                  <div className="font-medium">Distance from office:</div>
                  <div>{Math.round(distance)} meters</div>
                </>
              )}
            </div>

            {/* Success state */}
            {status === "success" && (
              <Alert className="bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-900">
                <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
                <AlertTitle>Location Verified</AlertTitle>
                <AlertDescription>You are at {officeLocation.name}. Your attendance can be recorded.</AlertDescription>
              </Alert>
            )}

            {/* Error state */}
            {status === "error" && error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Location Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}
          </div>
        )}

        {/* Retry button for error state */}
        {status === "error" && (
          <Button onClick={checkLocation} className="w-full mt-4 rounded-full animated-gradient-btn">
            <RefreshCw className="mr-2 h-4 w-4" />
            Retry Location Check
          </Button>
        )}
      </div>
    </div>
  )
}

