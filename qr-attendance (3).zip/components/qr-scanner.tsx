"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Camera, CameraOff, RefreshCw, SwitchCamera } from "lucide-react"
import jsQR from "jsqr"

interface QRScannerProps {
  onScan: (data: string) => void
  onError?: (error: Error) => void
}

export function QRScanner({ onScan, onError }: QRScannerProps) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [scanning, setScanning] = useState(false)
  const [cameraError, setCameraError] = useState<string | null>(null)
  const [facingMode, setFacingMode] = useState<"environment" | "user">("environment")
  const scanIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const streamRef = useRef<MediaStream | null>(null)

  // Start camera and QR scanning
  const startScanner = async () => {
    try {
      setCameraError(null)
      setScanning(true)

      // Stop any existing stream
      if (streamRef.current) {
        streamRef.current.getTracks().forEach((track) => track.stop())
      }

      // Request camera access with specific constraints for better performance
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode,
          width: { ideal: 1280 },
          height: { ideal: 720 },
          frameRate: { ideal: 30 },
        },
      })

      streamRef.current = stream

      // Set video source
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        await videoRef.current.play()

        // Start scanning for QR codes
        startQRDetection()
      }
    } catch (error: any) {
      console.error("Camera access error:", error)
      setScanning(false)

      // Provide user-friendly error messages
      if (error.name === "NotAllowedError") {
        setCameraError("Camera access denied. Please allow camera access and try again.")
      } else if (error.name === "NotFoundError") {
        setCameraError("No camera found. Please ensure your device has a working camera.")
      } else if (error.name === "NotReadableError") {
        setCameraError("Camera is in use by another application. Please close other apps using the camera.")
      } else {
        setCameraError(`Camera error: ${error.message || "Unknown error"}`)
      }

      onError?.(error)
    }
  }

  // Stop camera and scanning
  const stopScanner = () => {
    setScanning(false)

    // Clear scanning interval
    if (scanIntervalRef.current) {
      clearInterval(scanIntervalRef.current)
      scanIntervalRef.current = null
    }

    // Stop camera stream
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop())
      streamRef.current = null
    }

    // Clear video source
    if (videoRef.current) {
      videoRef.current.srcObject = null
    }
  }

  // Switch between front and back camera
  const switchCamera = async () => {
    setFacingMode((prev) => (prev === "environment" ? "user" : "environment"))

    // Restart scanner with new facing mode
    if (scanning) {
      stopScanner()
      setTimeout(() => {
        startScanner()
      }, 300)
    }
  }

  // Start QR code detection loop
  const startQRDetection = () => {
    if (!canvasRef.current || !videoRef.current) return

    const canvas = canvasRef.current
    const context = canvas.getContext("2d")
    if (!context) return

    // Clear any existing interval
    if (scanIntervalRef.current) {
      clearInterval(scanIntervalRef.current)
    }

    // Set up scanning interval
    scanIntervalRef.current = setInterval(() => {
      if (!scanning || !videoRef.current || !context) return

      // Only process if video is playing and has enough data
      if (videoRef.current.readyState === videoRef.current.HAVE_ENOUGH_DATA) {
        // Set canvas size to match video
        canvas.width = videoRef.current.videoWidth
        canvas.height = videoRef.current.videoHeight

        // Draw current video frame to canvas
        context.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height)

        // Get image data for QR processing
        const imageData = context.getImageData(0, 0, canvas.width, canvas.height)

        try {
          // Process with jsQR
          const qrCode = jsQR(imageData.data, imageData.width, imageData.height, {
            inversionAttempts: "dontInvert",
          })

          // If QR code found
          if (qrCode) {
            // Draw QR code location for visual feedback
            context.beginPath()
            context.moveTo(qrCode.location.topLeftCorner.x, qrCode.location.topLeftCorner.y)
            context.lineTo(qrCode.location.topRightCorner.x, qrCode.location.topRightCorner.y)
            context.lineTo(qrCode.location.bottomRightCorner.x, qrCode.location.bottomRightCorner.y)
            context.lineTo(qrCode.location.bottomLeftCorner.x, qrCode.location.bottomLeftCorner.y)
            context.lineTo(qrCode.location.topLeftCorner.x, qrCode.location.topLeftCorner.y)
            context.lineWidth = 4
            context.strokeStyle = "#3cefff"
            context.stroke()

            // Pass QR data to callback
            onScan(qrCode.data)

            // Stop scanning after successful detection
            stopScanner()
          }
        } catch (error) {
          console.error("QR processing error:", error)
        }
      }
    }, 100) // Scan every 100ms
  }

  // Auto-start scanner on mount
  useEffect(() => {
    startScanner()

    // Cleanup on unmount
    return () => {
      stopScanner()
    }
  }, [])

  return (
    <div className="relative w-full">
      {/* Video element for camera feed */}
      <div className="relative aspect-video bg-muted rounded-lg overflow-hidden">
        <video ref={videoRef} className="absolute inset-0 w-full h-full object-cover" playsInline muted />

        {/* QR scanning overlay */}
        {scanning && !cameraError && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-2/3 h-2/3 border-2 border-dashed border-primary/70 rounded-lg qr-scanner-overlay">
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-xs text-white bg-black/50 px-2 py-1 rounded-full">Position QR code here</span>
              </div>
            </div>
          </div>
        )}

        {/* Error state */}
        {cameraError && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-muted/90 p-4">
            <CameraOff className="h-12 w-12 text-destructive mb-2" />
            <p className="text-center text-destructive font-medium mb-2">Camera Error</p>
            <p className="text-center text-sm text-muted-foreground mb-4">{cameraError}</p>
            <Button onClick={startScanner} variant="default" size="sm" className="rounded-full animated-gradient-btn">
              <RefreshCw className="mr-2 h-4 w-4" />
              Retry Camera
            </Button>
          </div>
        )}

        {/* Loading state */}
        {scanning && !cameraError && !streamRef.current && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-muted/90">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mb-4"></div>
            <p className="text-muted-foreground">Accessing camera...</p>
            <p className="text-xs text-muted-foreground mt-1">Please allow camera access when prompted</p>
          </div>
        )}
      </div>

      {/* Hidden canvas for QR processing */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Controls */}
      <div className="flex justify-between mt-4">
        <Button
          variant="outline"
          size="sm"
          onClick={switchCamera}
          className="rounded-full"
          disabled={!scanning || !!cameraError}
        >
          <SwitchCamera className="mr-2 h-4 w-4" />
          Switch Camera
        </Button>

        <Button
          variant={scanning ? "outline" : "default"}
          size="sm"
          onClick={scanning ? stopScanner : startScanner}
          className={`rounded-full ${!scanning ? "animated-gradient-btn" : ""}`}
        >
          {scanning ? (
            <>
              <CameraOff className="mr-2 h-4 w-4" />
              Stop Camera
            </>
          ) : (
            <>
              <Camera className="mr-2 h-4 w-4" />
              Start Camera
            </>
          )}
        </Button>
      </div>
    </div>
  )
}

